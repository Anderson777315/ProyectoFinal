package Controlador;

import Modelo.Cabeceraventa;
import Modelo.Detalle_Venta;
import dao.CabeceraVentaDAO;
import dao.DetalleVentaDAO;
import Conexion.CreateConection;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class registrarVentaCompleta {
    
    public boolean registrarVenta(Cabeceraventa cabecera, List<Detalle_Venta> detalles) {
        Connection conn = null;
        try {
            // 1. Obtener conexión a la base de datos
            CreateConection connFactory = new CreateConection();
            conn = connFactory.getConnection();
            
            // 2. Iniciar transacción
            conn.setAutoCommit(false);
            
            // 3. Insertar cabecera de venta
            CabeceraVentaDAO cabeceraDAO = new CabeceraVentaDAO();
            int idCabecera = cabeceraDAO.insertarCabeceraVenta(conn, cabecera);
            
            if (idCabecera == -1) {
                // Si no se pudo insertar la cabecera, hacer rollback
                conn.rollback();
                return false;
            }
            
            // 4. Insertar detalles de venta
            DetalleVentaDAO detalleDAO = new DetalleVentaDAO();
            for (Detalle_Venta detalle : detalles) {
                // Asignar el ID de la cabecera al detalle
                detalle.setIdventa(idCabecera);
                
                if (!detalleDAO.insertarDetalleVenta(conn, detalle)) {
                    // Si falla algún detalle, hacer rollback
                    conn.rollback();
                    return false;
                }
            }
            
            // 5. Confirmar transacción si todo fue exitoso
            conn.commit();
            return true;
            
        } catch (SQLException e) {
            // 6. Manejar errores: rollback en caso de excepción
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
            return false;
        } finally {
            // 7. Cerrar conexión siempre
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}