package Controlador;

// Se importan las librerías necesarias para la conexión a la base de datos y manejo de excepciones SQL.
import Modelo.Cliente; // Se asume que tienes una clase Cliente en el paquete Modelo.
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

// Se importan las librerías de iText para la generación de documentos PDF.
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Image; // Para agregar imágenes al PDF.
import com.itextpdf.text.Font; // Para manejar fuentes de texto.
import com.itextpdf.text.BaseColor; // Para manejar colores.
import com.itextpdf.text.Chunk; // Para añadir trozos de texto.
import com.itextpdf.text.Element; // Para alineación de elementos.
import Vista.Facturacion;

// Se importan las librerías para manejo de archivos y fechas.
import Conexion.CreateConection; // Se asume que tienes una clase CreateConection en el paquete Conexion.
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.Desktop; // Para abrir el archivo PDF automáticamente después de crearlo.


/**
 * Esta clase se encarga de generar facturas en formato PDF.
 * Recupera datos del cliente y de los productos de una tabla (asumiendo que viene de un JFrame de Facturacion).
 *
 * @author JOSUE RAMOS
 */
public class VentaPDF {
    // Atributos para almacenar los datos del cliente y el nombre del archivo PDF.
    protected String nombreCliente;
    protected String gmail;
    protected String TelefonoCliente;
    protected String DireccionCliente;
    protected String fechaActual = "";
    protected String nombreArchivoPDFVenta = "";

    // Instancia de la clase de conexión a la base de datos.
    private CreateConection connFactory = new CreateConection(); // Instancia de la clase de conexión

    /**
     * Este método obtiene los datos de un cliente desde la base de datos
     * basándose en su ID.
     *
     * @param idCliente El ID del cliente a buscar.
     */
    public void DatosCliente(int idCliente) {
        // Consulta SQL para seleccionar todos los datos del cliente con el ID proporcionado.
        // **CORRECCIÓN:** La variable 'id' estaba mal, debe ser 'idCliente'.
        String sql = "SELECT * FROM CLIENTE WHERE id = ?";

        try (Connection conn = connFactory.getConnection(); // Obtiene la conexión a la base de datos.
             PreparedStatement ps = conn.prepareStatement(sql)) { // Prepara la consulta SQL.

            ps.setInt(1, idCliente); // Establece el parámetro del ID del cliente en la consulta.

            try (ResultSet rs = ps.executeQuery()) { // Ejecuta la consulta y obtiene el resultado.
                if (rs.next()) { // Si se encuentra un registro, se extraen los datos.
                    nombreCliente = rs.getString("nombre") + " " + rs.getString("apellido");
                    gmail = rs.getString("gmail");
                    TelefonoCliente = rs.getString("telefono");
                    DireccionCliente = rs.getString("direccion");
                }
            }

        } catch (SQLException e) {
            // Manejo de errores en caso de problemas al obtener los datos del cliente.
            System.out.println("Error al obtener datos del cliente: " + e.getMessage());
        }
    }


    public void generarFacturaPDF() {
        try {
       
            Date date = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
            fechaActual = sdf.format(date);

            String fechaNueva = fechaActual.replace("/", "_");
            nombreArchivoPDFVenta = "Venta_" + nombreCliente.replace(" ", "_") + "_" + fechaNueva + ".pdf";

            FileOutputStream archivo;
  
            File file = new File("src/pdf/" + nombreArchivoPDFVenta);
            archivo = new FileOutputStream(file);

            // Se crea un nuevo documento PDF.
            Document doc = new Document();
            // Se asocia el escritor de PDF al documento y al flujo de salida del archivo.
            PdfWriter.getInstance(doc, archivo);
            doc.open(); // Se abre el documento para empezar a añadir contenido.

            Image img = Image.getInstance("src/img/ventasss1.png");
  
            img.scaleToFit(100, 100); // Ajusta el tamaño de la imagen (ancho, alto).
            img.setAlignment(Element.ALIGN_LEFT); // Alinea la imagen a la izquierda.


            Paragraph fecha = new Paragraph();

            Font negrita = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLUE);

            fecha.add(Chunk.NEWLINE); // Agrega una nueva línea.
            // **CORRECCIÓN:** Errores de caligrafía y formato en el texto.
            fecha.add("Factura: 001" + "\nFecha: " + fechaActual + "\n\n"); // Se agrega el número de factura y la fecha.

            // Se crea una tabla para el encabezado del documento (logo, datos de la empresa, fecha).
            // **CORRECCIÓN:** Nombre de la clase PdfPTable.
            PdfPTable Encabezado = new PdfPTable(4);
            Encabezado.setWidthPercentage(100); // La tabla ocupa el 100% del ancho de la página.
            Encabezado.getDefaultCell().setBorder(0); // Quita los bordes por defecto de las celdas.

            // Define el ancho relativo de las columnas del encabezado.
            float[] ColumnaEncabezado = new float[]{20f, 30f, 70f, 40f};
            // **CORRECCIÓN:** Nombre del método setWidths.
            Encabezado.setWidths(ColumnaEncabezado);
            // **CORRECCIÓN:** Error de caligrafía en la alineación.
            Encabezado.setHorizontalAlignment(Element.ALIGN_LEFT);

            // Agrega las celdas al encabezado.
            Encabezado.addCell(img); // Celda para la imagen.

            // Datos de la empresa.
            String ruc = "3216549821";
            String nombreEmpresa = "COMO DICE EL DICHO"; // Renombrado para evitar conflicto con nombreCliente
            String telefonoEmpresa = "321457854"; // Renombrado
            String direccionEmpresa = "Antigua Guatemala"; // Renombrado
            String razonSocial = "No hay mal que dure cien años ni quien la aguante XD"; // Renombrado

            Encabezado.addCell(""); // Celda vacía para espacio.
           Encabezado.addCell("RUC: " + ruc + "\nNOMBRE: " + nombreEmpresa + "\nTELÉFONO: " + telefonoEmpresa + "\nDIRECCIÓN: " + direccionEmpresa + "\nRAZÓN SOCIAL: " + razonSocial);
            Encabezado.addCell(fecha); // Celda para la fecha.
            doc.add(Encabezado); // Agrega el encabezado al documento.

           Paragraph clienteInfo = new Paragraph(); // Renombrado para mayor claridad
            clienteInfo.add("Datos del cliente:\n\n");
            doc.add(clienteInfo);
   PdfPTable tablaCliente = new PdfPTable(4);
            tablaCliente.setWidthPercentage(100);
            tablaCliente.getDefaultCell().setBorder(0);
  float[] ColumnaCliente = new float[]{25f, 45f, 30f, 40f};
            // **CORRECCIÓN:** Nombre del método setWidths.
            tablaCliente.setWidths(ColumnaCliente);
            // **CORRECCIÓN:** Error de caligrafía en la alineación.
            tablaCliente.setHorizontalAlignment(Element.ALIGN_LEFT);

            // Crea las celdas de encabezado para la tabla de cliente.
            // **CORRECCIÓN:** Se usa Phrase para el texto.
            PdfPCell cliente1 = new PdfPCell(new Phrase("Nombre:", negrita));
            PdfPCell cliente2 = new PdfPCell(new Phrase("Gmail:", negrita));
            PdfPCell cliente3 = new PdfPCell(new Phrase("Teléfono:", negrita));
            PdfPCell cliente4 = new PdfPCell(new Phrase("Dirección:", negrita));

            // Quita los bordes de las celdas de encabezado.
            cliente1.setBorder(0);
            cliente2.setBorder(0);
            cliente3.setBorder(0);
            cliente4.setBorder(0);

            // Agrega las celdas de encabezado a la tabla.
            tablaCliente.addCell(cliente1);
            tablaCliente.addCell(cliente2);
            tablaCliente.addCell(cliente3);
            tablaCliente.addCell(cliente4);

           tablaCliente.addCell(nombreCliente); // Aquí se podría usar un ID de cliente si fuera necesario
            tablaCliente.addCell(gmail);
            tablaCliente.addCell(TelefonoCliente);
            tablaCliente.addCell(DireccionCliente);
       doc.add(tablaCliente);
      Paragraph espacio = new Paragraph();
            espacio.add(Chunk.NEWLINE);
            espacio.add("");
            // **CORRECCIÓN:** Error de caligrafía en la alineación.
            espacio.setAlignment(Element.ALIGN_CENTER);
            doc.add(espacio);
         PdfPTable tablaProducto = new PdfPTable(4);
            tablaProducto.setWidthPercentage(100);
            tablaProducto.getDefaultCell().setBorder(0);
        float[] ColumnaProducto = new float[]{15f, 50f, 15f, 20f};
             tablaProducto.setWidths(ColumnaProducto);
            tablaProducto.setHorizontalAlignment(Element.ALIGN_LEFT);
      PdfPCell producto1 = new PdfPCell(new Phrase("Cantidad", negrita));
            PdfPCell producto2 = new PdfPCell(new Phrase("Descripción", negrita));
            PdfPCell producto3 = new PdfPCell(new Phrase("Precio Unitario", negrita));
            PdfPCell producto4 = new PdfPCell(new Phrase("Precio Total", negrita));

            // Quita los bordes de las celdas de encabezado de productos.
            producto1.setBorder(0);
            producto2.setBorder(0);
            producto3.setBorder(0);
            producto4.setBorder(0);

            // Agrega color de fondo a las celdas de encabezado de productos.
            producto1.setBackgroundColor(BaseColor.LIGHT_GRAY);
            producto2.setBackgroundColor(BaseColor.LIGHT_GRAY);
            producto3.setBackgroundColor(BaseColor.LIGHT_GRAY);
            producto4.setBackgroundColor(BaseColor.LIGHT_GRAY);

            // Agrega las celdas de encabezado a la tabla de productos.
            tablaProducto.addCell(producto1);
            tablaProducto.addCell(producto2);
            tablaProducto.addCell(producto3);
            tablaProducto.addCell(producto4);
      for (int i = 0; i < Facturacion.jTable_productos.getRowCount(); i++) {
                String producto = Facturacion.jTable_productos.getValueAt(i, 1).toString();
                String cantidad = Facturacion.jTable_productos.getValueAt(i, 2).toString();
                String precio = Facturacion.jTable_productos.getValueAt(i, 3).toString();
                String total = Facturacion.jTable_productos.getValueAt(i, 4).toString();
           tablaProducto.addCell(cantidad);
                tablaProducto.addCell(producto);
                tablaProducto.addCell(precio);
                tablaProducto.addCell(total);
            }
            // Agrega la tabla de productos al documento.
            doc.add(tablaProducto);

            // --- Total a Pagar ---
            Paragraph info = new Paragraph();
            info.add(Chunk.NEWLINE);
            // **CORRECCIÓN:** Acceso al texto del total a pagar.
            info.add("Total a pagar: " + Facturacion.txtTotalpagar.getText());
            // **CORRECCIÓN:** Error de caligrafía en la alineación.
            info.setAlignment(Element.ALIGN_RIGHT);
            // **CORRECCIÓN:** Nombre del método add.
            doc.add(info);
     Paragraph firma = new Paragraph();
            firma.add(Chunk.NEWLINE);
            firma.add("Cancelación y Firma\n\n");
            firma.add("________________________");
             firma.setAlignment(Element.ALIGN_CENTER);
            doc.add(firma);
       Paragraph mensaje = new Paragraph();
            mensaje.add(Chunk.NEWLINE);
            mensaje.add("¡Gracias por su compra, vuelva pronto!");
            // **CORRECCIÓN:** Error de caligrafía en la alineación.
            mensaje.setAlignment(Element.ALIGN_CENTER);
            doc.add(mensaje);

            // Cierra el documento y el flujo de salida del archivo.
            doc.close();
            archivo.close();

            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(file);
            } else {
                System.out.println("Desktop no soportado, no se puede abrir el PDF automáticamente.");
            }

        } catch (DocumentException | IOException e) {
            System.out.println("Error al generar el PDF: " + e.getMessage());
        } catch (Exception e) {
           System.out.println("Ocurrió un error inesperado: " + e.getMessage());
            e.printStackTrace(); // Imprime la traza completa del error para depuración.
        }
    }
}
