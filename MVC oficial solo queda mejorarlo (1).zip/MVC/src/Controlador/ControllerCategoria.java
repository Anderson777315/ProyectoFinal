/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import dao.ClienteDAO;
    import Modelo.Categorias;
import dao.Categoria1;
    import java.util.List;

/**
 *
 * @author JOSUE RAMOS
 */
public class ControllerCategoria {
    
    private final Categoria1  dao = new Categoria1 ();
    public List<Categorias> obtenerCategoria (){
    return dao.obtenerTodos();
    }//constructor
     public boolean guardar(Categorias categoria) {
        return dao.guardar(categoria);
    }
 public void agregarCategoria(String descripcion, String nombre, int estado) { // Corregido nombre del parámetro
        
        Categorias cat = new Categorias(0, nombre, descripcion, estado);
        dao.guardar(cat);
    }

    public boolean  actualizarCategoria(int id, String descripcion, String nombre, int estado) { // Corregido nombre del parámetro
  
        Categorias cat = new Categorias(id, descripcion, nombre, estado); // Variable corregida
        return dao.actualizar(cat);
    }

    public boolean  eliminarCategoria(int id) {
         return dao.eliminar(id);
    }

    /*public Categorias buscarCategoria(int id) {
        return dao.Consultar(id);
    }*/
}
