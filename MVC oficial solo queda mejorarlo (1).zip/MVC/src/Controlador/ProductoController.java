package Controlador;

import dao.ProductoDAO;
import Modelo.Producto;
import java.util.List;

public class ProductoController {
    private final ProductoDAO dao = new ProductoDAO();
    public List<Producto> obtenerProductos() {
        return dao.obtenerTodos();
    }

    public void agregarProducto(String nombre, double precio, int stock, boolean disponible, int porcentajeIva, String categoria ) {
        Producto p = new Producto(0, nombre, precio, stock, disponible,porcentajeIva,categoria);
         dao.guardar(p);
    }

    public void actualizarProducto(int id, String nombre, double precio, int stock, boolean disponible, int porcentajeIva,String categoria) {
        Producto p = new Producto(id, nombre, precio, stock, disponible,porcentajeIva,categoria);
        dao.actualizar(p);
    }

    public boolean eliminarProducto(int id) {
        return dao.eliminar(id);
    }
    // En la clase ProductoController
public Producto obtenerProductoPorId(int id) {
    return dao.obtenerProductoPorId(id);
}
}
