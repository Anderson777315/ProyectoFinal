package Controlador;

import dao.ProveedorDAO;
import Modelo.Proveedor;
import java.util.List;

public class ProveedorController {

    private final ProveedorDAO dao = new ProveedorDAO();

    public void agregarProveedor(String nombre, String nit, String contacto, String direccion, String telefonoemp, String telefonocon) {
        Proveedor pro = new Proveedor(nombre, nit, contacto, direccion, telefonoemp, telefonocon);
        dao.guardar(pro);
    }

    public boolean actualizarProveedor(int id, String nombre, String nit, String contacto, String direccion, String telefonoemp, String telefonocon) {
        Proveedor pro = new Proveedor(id, nombre, nit, contacto, direccion, telefonoemp, telefonocon);
        return dao.actualizar(pro);
    }

    public boolean eliminarProveedor(int id) {
        return dao.eliminar(id);
    }

 
}
