package Conexion;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class CreateConection {
    private static final String CONFIG_FILE = "Conexion/configuration.properties"; // Ruta relativa
    private static Properties configuracion = new Properties();

    static {
        // Cargar el archivo de propiedades desde el classpath
        try (InputStream in = CreateConection.class.getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            configuracion.load(in);
            System.out.println("Archivo de configuración cargado exitosamente");
        } catch (IOException e) {
            System.err.println("Error al cargar el archivo de configuración: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        String hostname = configuracion.getProperty("hostname");
        String port = configuracion.getProperty("port");
        String database = configuracion.getProperty("database");
        String username = configuracion.getProperty("username");
        String password = configuracion.getProperty("password");

        String jdbcUrl = "jdbc:postgresql://" + hostname + ":" + port + "/" + database;
        return DriverManager.getConnection(jdbcUrl, username, password);
    }
}
