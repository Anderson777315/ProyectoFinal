package Modelo;

public class Cabeceraventa {

   protected int idcabeceraventa;
    protected int idcliente;
    protected int idempleado; // Nuevo campo
    protected double valorpagar;
    protected String fechaventa;
    protected int estado;

    public Cabeceraventa() {
          this.idcabeceraventa = 0;
        this.idcliente = 0;
        this.idempleado = 0; // Inicializado
        this.valorpagar = 0;
        this.fechaventa = "";
        this.estado = 0;
    }

    public Cabeceraventa(int idcabeceraventa, int idcliente, int idempleado, double valorpagar, String fechaventa, int estado) {
        this.idcabeceraventa = idcabeceraventa;
        this.idcliente = idcliente;
        this.idempleado = idempleado;
        this.valorpagar = valorpagar;
        this.fechaventa = fechaventa;
        this.estado = estado;
    }

    public int getIdcabeceraventa() {
        return idcabeceraventa;
    }

    public void setIdcabeceraventa(int idcabeceraventa) {
        this.idcabeceraventa = idcabeceraventa;
    }

    public int getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(int idcliente) {
        this.idcliente = idcliente;
    }

    public int getIdempleado() {
        return idempleado;
    }

    public void setIdempleado(int idempleado) {
        this.idempleado = idempleado;
    }

    public double getValorpagar() {
        return valorpagar;
    }

    public void setValorpagar(double valorpagar) {
        this.valorpagar = valorpagar;
    }

    public String getFechaventa() {
        return fechaventa;
    }

    public void setFechaventa(String fechaventa) {
        this.fechaventa = fechaventa;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }


}