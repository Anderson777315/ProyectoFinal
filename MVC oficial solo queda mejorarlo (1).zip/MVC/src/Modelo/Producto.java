package Modelo;

public class Producto {
    protected int id;
    protected String nombre;
    protected double precio;
    protected int stock;
    protected boolean disponible;
    protected int porcentajeIva;
    protected String categoria; // Cambiado a String

    public Producto() {
        this.id = 0;
        this.nombre = "";
        this.precio = 0;
        this.stock = 0;
        this.disponible = false;
        this.porcentajeIva = 0;
        this.categoria = ""; // Inicializado como String vacío
    }

    // Constructor actualizado
    public Producto(
        int id, 
        String nombre, 
        double precio, 
        int stock, 
        boolean disponible, 
        int porcentajeIva, 
        String categoria // Cambiado a String
    ) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
        this.disponible = disponible;
        this.porcentajeIva = porcentajeIva;
        this.categoria = categoria;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public int getPorcentajeIva() {
        return porcentajeIva;
    }

    public void setPorcentajeIva(int porcentajeIva) {
        this.porcentajeIva = porcentajeIva;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

}