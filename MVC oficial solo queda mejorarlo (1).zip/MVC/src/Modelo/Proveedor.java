/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

public class Proveedor {
    private int id;  // <-- Agregado
    private String nombre;
    private String nit;
    private String contacto;
    private String direccion;
    private String telefonoEmp;
    private String telefonoCon;

    public Proveedor() {
        this.nombre = "";
        this.nit = "";
        this.contacto = "";
        this.direccion = "";
        this.telefonoEmp = "";
        this.telefonoCon = "";
    }

    // Constructor para insertar nuevo proveedor (sin ID)
    public Proveedor(String nombre, String nit, String contacto, String direccion, String telefonoEmp, String telefonoCon) {
        this.nombre = nombre;
        this.nit = nit;
        this.contacto = contacto;
        this.direccion = direccion;
        this.telefonoEmp = telefonoEmp;
        this.telefonoCon = telefonoCon;
    }

    // Constructor para actualizar proveedor (con ID)
    public Proveedor(int id, String nombre, String nit, String contacto, String direccion, String telefonoEmp, String telefonoCon) {
        this.id = id;
        this.nombre = nombre;
        this.nit = nit;
        this.contacto = contacto;
        this.direccion = direccion;
        this.telefonoEmp = telefonoEmp;
        this.telefonoCon = telefonoCon;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public String getContacto() {
        return contacto;
    }

    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefonoEmp() {
        return telefonoEmp;
    }

    public void setTelefonoEmp(String telefonoEmp) {
        this.telefonoEmp = telefonoEmp;
    }

    public String getTelefonoCon() {
        return telefonoCon;
    }

    public void setTelefonoCon(String telefonoCon) {
        this.telefonoCon = telefonoCon;
    }
}

