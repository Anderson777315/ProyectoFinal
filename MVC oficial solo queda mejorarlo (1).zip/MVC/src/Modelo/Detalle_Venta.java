
package Modelo;

public class Detalle_Venta {
    protected int iddetalle;
    protected int idventa;
    protected int idproducto;
    protected String nombre;
    protected int cantidad;
    protected double preciounitario;
    protected double subtotal;
    protected double descuento;
    protected double iva;
    protected double totalpagar;
    protected int estado;
    
    public  Detalle_Venta() {
     this.iddetalle=0;
     this.idventa=0;
      this.idproducto=0;
     this.nombre="";
      this.cantidad=0;
      this.preciounitario=0.0;
      this.subtotal=0.0;
      this.descuento=0.0;
      this.iva=0.0;
      this.totalpagar=0.0;
      this.estado=0;
    }

    public Detalle_Venta(int iddetalle, int idventa, int idproducto, String nombre, int cantidad, double preciounitario, double subtotal, double descuento, double iva, double totalpagar, int estado) {
        this.iddetalle = iddetalle;
        this.idventa = idventa;
        this.idproducto = idproducto;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.preciounitario = preciounitario;
        this.subtotal = subtotal;
        this.descuento = descuento;
        this.iva = iva;
        this.totalpagar = totalpagar;
        this.estado = estado;
    }

    public int getIddetalle() {
        return iddetalle;
    }

    public void setIddetalle(int iddetalle) {
        this.iddetalle = iddetalle;
    }

    public int getIdventa() {
        return idventa;
    }

    public void setIdventa(int idventa) {
        this.idventa = idventa;
    }

    public int getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(int idproducto) {
        this.idproducto = idproducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPreciounitario() {
        return preciounitario;
    }

    public void setPreciounitario(double preciounitario) {
        this.preciounitario = preciounitario;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getIva() {
        return iva;
    }

    public void setIva(double iva) {
        this.iva = iva;
    }

    public double getTotalpagar() {
        return totalpagar;
    }

    public void setTotalpagar(double totalpagar) {
        this.totalpagar = totalpagar;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Detalle_Venta{" + "iddetalle=" + iddetalle + ", idventa=" + idventa + ", idproducto=" + idproducto + ", nombre=" + nombre + ", cantidad=" + cantidad + ", preciounitario=" + preciounitario + ", subtotal=" + subtotal + ", descuento=" + descuento + ", iva=" + iva + ", totalpagar=" + totalpagar + ", estado=" + estado + '}';
    }
    
}
