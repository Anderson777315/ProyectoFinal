/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Vista.Categoria;
import java.awt.Dimension;
import javax.swing.JDesktopPane;

/**
 *
 * @author JOSUE RAMOS
 */
public class Menu extends javax.swing.JFrame {
        public static JDesktopPane JDesktopPane_menu;
    /**
     * Creates new form Menu
     */
    public Menu() {
        initComponents();
        this.setSize(new Dimension(1200,800));
        this.setExtendedState(this.MAXIMIZED_BOTH);
        this.setLocationRelativeTo(null);
        this.setTitle("Sistema de Restaurante");
        
        this.setLayout(null);
        JDesktopPane_menu =new JDesktopPane();
        
        int ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
        int alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
        this.JDesktopPane_menu.setBounds(0 ,0,ancho,(alto-110));
        this.add(JDesktopPane_menu);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu7 = new javax.swing.JMenu();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem_nuevo_clientes = new javax.swing.JMenuItem();
        jMenuItem_gestionar_clientes = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem_nuevo_producto = new javax.swing.JMenuItem();
        jMenuItem_gestionar_producto = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem_nuevos_proveedores = new javax.swing.JMenuItem();
        jMenuItem_gestion_productos = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenuItem_nuevo_ususarios = new javax.swing.JMenuItem();
        jMenuItem_gestionar_usuarisos = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem_nueva_venta = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem_nuevo_empleados = new javax.swing.JMenuItem();
        jMenuItem_gestion_empleados = new javax.swing.JMenuItem();
        jMenu8 = new javax.swing.JMenu();
        jMenuItem_reportes_usuario = new javax.swing.JMenuItem();
        jMenuItem_reportes_productos = new javax.swing.JMenuItem();
        jMenuItem_reportes_ventas = new javax.swing.JMenuItem();
        jMenuItem_reportes_ventas1 = new javax.swing.JMenuItem();
        jMenu9 = new javax.swing.JMenu();
        jMenuItem_cerrar_sesion = new javax.swing.JMenuItem();

        jMenu7.setText("jMenu7");

        jMenuItem10.setText("jMenuItem10");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/usuario.png"))); // NOI18N
        jMenu1.setText("Clientes");
        jMenu1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenu1.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevo_clientes.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_nuevo_clientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-cliente.png"))); // NOI18N
        jMenuItem_nuevo_clientes.setText("Nuevo Clientes");
        jMenuItem_nuevo_clientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevo_clientesActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem_nuevo_clientes);

        jMenuItem_gestionar_clientes.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_gestionar_clientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/configuraciones.png"))); // NOI18N
        jMenuItem_gestionar_clientes.setText("Gestionar Clientes");
        jMenuItem_gestionar_clientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionar_clientesActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem_gestionar_clientes);

        jMenuBar1.add(jMenu1);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/producto.png"))); // NOI18N
        jMenu2.setText("Productos");
        jMenu2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenu2.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevo_producto.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_nuevo_producto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-producto.png"))); // NOI18N
        jMenuItem_nuevo_producto.setText("Nuevo Producto");
        jMenuItem_nuevo_producto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevo_productoActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem_nuevo_producto);

        jMenuItem_gestionar_producto.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_gestionar_producto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/producto.png"))); // NOI18N
        jMenuItem_gestionar_producto.setText("Gestionar Producto");
        jMenuItem_gestionar_producto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionar_productoActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem_gestionar_producto);

        jMenuBar1.add(jMenu2);

        jMenu3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/propor.png"))); // NOI18N
        jMenu3.setText("Proveedores");
        jMenu3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenu3.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevos_proveedores.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_nuevos_proveedores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo.png"))); // NOI18N
        jMenuItem_nuevos_proveedores.setText("Nuevos Proveedores");
        jMenuItem_nuevos_proveedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevos_proveedoresActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem_nuevos_proveedores);

        jMenuItem_gestion_productos.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_gestion_productos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        jMenuItem_gestion_productos.setText("Gestion de Proveedores");
        jMenuItem_gestion_productos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestion_productosActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem_gestion_productos);

        jMenuBar1.add(jMenu3);

        jMenu4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        jMenu4.setText("Usuarios");
        jMenu4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenu4.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevo_ususarios.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_nuevo_ususarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-cliente.png"))); // NOI18N
        jMenuItem_nuevo_ususarios.setText("Nuevos Usuarios");
        jMenuItem_nuevo_ususarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevo_ususariosActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem_nuevo_ususarios);

        jMenuItem_gestionar_usuarisos.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_gestionar_usuarisos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        jMenuItem_gestionar_usuarisos.setText("Gestionar Usuarios");
        jMenuItem_gestionar_usuarisos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionar_usuarisosActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem_gestionar_usuarisos);

        jMenuBar1.add(jMenu4);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/carrito.png"))); // NOI18N
        jMenu5.setText("Facturar");
        jMenu5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenu5.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nueva_venta.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_nueva_venta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anadir.png"))); // NOI18N
        jMenuItem_nueva_venta.setText("Nueva Venta");
        jMenuItem_nueva_venta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nueva_ventaActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem_nueva_venta);

        jMenuBar1.add(jMenu5);

        jMenu6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/empleado.png"))); // NOI18N
        jMenu6.setText("Empleado");
        jMenu6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenu6.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevo_empleados.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_nuevo_empleados.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-cliente.png"))); // NOI18N
        jMenuItem_nuevo_empleados.setText("Nuevo Empleados");
        jMenuItem_nuevo_empleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevo_empleadosActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem_nuevo_empleados);

        jMenuItem_gestion_empleados.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_gestion_empleados.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        jMenuItem_gestion_empleados.setText("Gestion de Empleados");
        jMenuItem_gestion_empleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestion_empleadosActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem_gestion_empleados);

        jMenuBar1.add(jMenu6);

        jMenu8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reportes.png"))); // NOI18N
        jMenu8.setText("Reportes");
        jMenu8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenu8.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_reportes_usuario.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_reportes_usuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reporte1.png"))); // NOI18N
        jMenuItem_reportes_usuario.setText("Resportes Usuarios");
        jMenuItem_reportes_usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_reportes_usuarioActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem_reportes_usuario);

        jMenuItem_reportes_productos.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_reportes_productos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reporte1.png"))); // NOI18N
        jMenuItem_reportes_productos.setText("Resportes Productos");
        jMenuItem_reportes_productos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_reportes_productosActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem_reportes_productos);

        jMenuItem_reportes_ventas.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_reportes_ventas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reporte1.png"))); // NOI18N
        jMenuItem_reportes_ventas.setText("Reportes Ventas");
        jMenuItem_reportes_ventas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_reportes_ventasActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem_reportes_ventas);

        jMenuItem_reportes_ventas1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_reportes_ventas1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reporte1.png"))); // NOI18N
        jMenuItem_reportes_ventas1.setText("R Ventas por fecha");
        jMenuItem_reportes_ventas1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_reportes_ventas1ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem_reportes_ventas1);

        jMenuBar1.add(jMenu8);

        jMenu9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cerrar-sesion.png"))); // NOI18N
        jMenu9.setText("Cerrar Sesion");
        jMenu9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenu9.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_cerrar_sesion.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuItem_cerrar_sesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cerrar-sesion.png"))); // NOI18N
        jMenuItem_cerrar_sesion.setText("Cerrar Sesion");
        jMenuItem_cerrar_sesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_cerrar_sesionActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem_cerrar_sesion);

        jMenuBar1.add(jMenu9);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem_nuevo_productoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevo_productoActionPerformed
         Producto1 producto =new Producto1();
        JDesktopPane_menu.add(producto);
        producto.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevo_productoActionPerformed

    private void jMenuItem_reportes_usuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_reportes_usuarioActionPerformed
        Reportes1 reporte =new Reportes1();
        reporte.ReportesUsuarios();
        
    }//GEN-LAST:event_jMenuItem_reportes_usuarioActionPerformed

    private void jMenuItem_reportes_productosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_reportes_productosActionPerformed
        ReportesProductos ReportesProductos =new ReportesProductos();
        ReportesProductos.ReportesProductos();
    }//GEN-LAST:event_jMenuItem_reportes_productosActionPerformed

    private void jMenuItem_cerrar_sesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_cerrar_sesionActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jMenuItem_cerrar_sesionActionPerformed

    private void jMenuItem_gestionar_usuarisosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionar_usuarisosActionPerformed
        GestionarUsuarios usuario =new GestionarUsuarios();
        JDesktopPane_menu.add(usuario);
        usuario.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionar_usuarisosActionPerformed

    private void jMenuItem_reportes_ventasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_reportes_ventasActionPerformed
            ReporteVentas ReporteProductosMasVendidos =new ReporteVentas();
        ReporteProductosMasVendidos.ReporteProductosMasVendidos();
    }//GEN-LAST:event_jMenuItem_reportes_ventasActionPerformed

    private void jMenuItem_nuevo_clientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevo_clientesActionPerformed
       Clientess cliente =new Clientess();
        JDesktopPane_menu.add(cliente);
        cliente.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevo_clientesActionPerformed

    private void jMenuItem_gestionar_clientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionar_clientesActionPerformed
        // TODO add your handling code here:
         GestionarClientes gclientes =new GestionarClientes();
        JDesktopPane_menu.add(gclientes);
        gclientes.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionar_clientesActionPerformed

    private void jMenuItem_nuevo_empleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevo_empleadosActionPerformed
         Empleados1 emp =new Empleados1();
        JDesktopPane_menu.add(emp);
        emp.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevo_empleadosActionPerformed

    private void jMenuItem_gestionar_productoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionar_productoActionPerformed
        GestionarProductos gestionar =new GestionarProductos();
        JDesktopPane_menu.add(gestionar);
        gestionar.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionar_productoActionPerformed

    private void jMenuItem_nuevo_ususariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevo_ususariosActionPerformed
       Usuarios1 usuario =new Usuarios1();
        JDesktopPane_menu.add(usuario);
        usuario.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevo_ususariosActionPerformed

    private void jMenuItem_nuevos_proveedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevos_proveedoresActionPerformed
             Proveedores proveedor =new Proveedores();
        JDesktopPane_menu.add(proveedor);
        proveedor.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevos_proveedoresActionPerformed

    private void jMenuItem_gestion_productosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestion_productosActionPerformed
          GestionarProveedores gestionarp =new GestionarProveedores();
        JDesktopPane_menu.add(gestionarp);
        gestionarp.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestion_productosActionPerformed

    private void jMenuItem_gestion_empleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestion_empleadosActionPerformed
        GestionarEmpleado emp =new GestionarEmpleado();
        JDesktopPane_menu.add(emp);
        emp.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestion_empleadosActionPerformed

    private void jMenuItem_nueva_ventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nueva_ventaActionPerformed
        // TODO add your handling code here:
          Facturacion facturar =new Facturacion();
        JDesktopPane_menu.add(facturar);
        facturar.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nueva_ventaActionPerformed

    private void jMenuItem_reportes_ventas1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_reportes_ventas1ActionPerformed
       Reporteporfecha Reporteporfecha =new Reporteporfecha();
        Reporteporfecha.mostrarDialogoReporteVentas();
    }//GEN-LAST:event_jMenuItem_reportes_ventas1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenu jMenu9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem_cerrar_sesion;
    private javax.swing.JMenuItem jMenuItem_gestion_empleados;
    private javax.swing.JMenuItem jMenuItem_gestion_productos;
    private javax.swing.JMenuItem jMenuItem_gestionar_clientes;
    private javax.swing.JMenuItem jMenuItem_gestionar_producto;
    private javax.swing.JMenuItem jMenuItem_gestionar_usuarisos;
    private javax.swing.JMenuItem jMenuItem_nueva_venta;
    private javax.swing.JMenuItem jMenuItem_nuevo_clientes;
    private javax.swing.JMenuItem jMenuItem_nuevo_empleados;
    private javax.swing.JMenuItem jMenuItem_nuevo_producto;
    private javax.swing.JMenuItem jMenuItem_nuevo_ususarios;
    private javax.swing.JMenuItem jMenuItem_nuevos_proveedores;
    private javax.swing.JMenuItem jMenuItem_reportes_productos;
    private javax.swing.JMenuItem jMenuItem_reportes_usuario;
    private javax.swing.JMenuItem jMenuItem_reportes_ventas;
    private javax.swing.JMenuItem jMenuItem_reportes_ventas1;
    // End of variables declaration//GEN-END:variables
}
