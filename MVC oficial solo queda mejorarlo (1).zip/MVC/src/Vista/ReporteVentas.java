package Vista;

import Conexion.CreateConection;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import javax.swing.JOptionPane;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class ReporteVentas {

    public void ReporteProductosMasVendidos() {
        String filePath = System.getProperty("user.home") + "/Desktop/Productos_Mas_Vendidos.pdf";
        Document documento = new Document();
        try {
            PdfWriter.getInstance(documento, new FileOutputStream(filePath));

            // Título del reporte
            Paragraph titulo = new Paragraph("Reporte de Productos Más y Menos Vendidos", 
                                         FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20, BaseColor.DARK_GRAY));
            titulo.setAlignment(Element.ALIGN_CENTER);
            titulo.setSpacingAfter(20f);

            // Subtítulo
            Paragraph subtitulo = new Paragraph("Análisis de ventas por volumen de productos",
                                         FontFactory.getFont(FontFactory.HELVETICA, 14, BaseColor.GRAY));
            subtitulo.setAlignment(Element.ALIGN_CENTER);
            subtitulo.setSpacingAfter(30f);

            documento.open();
            documento.add(titulo);
            documento.add(subtitulo);

            // Tabla principal con ranking de productos
            PdfPTable tabla = new PdfPTable(4); // Columnas: Posición, Producto, Cantidad Vendida, Estado
            tabla.setWidthPercentage(100);
            tabla.setWidths(new float[]{1, 4, 2, 2});
            
            // Encabezados de tabla
            tabla.addCell(new Phrase("Posición", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
            tabla.addCell(new Phrase("Producto", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
            tabla.addCell(new Phrase("Cantidad Vendida", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
            tabla.addCell(new Phrase("Tendencia", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));

            try (Connection conn = new CreateConection().getConnection()) {
                // Consulta para obtener productos ordenados por ventas
                String sql = "SELECT p.id, p.nombre, SUM(dv.cantidad) AS total_vendido "
                           + "FROM detalleventa dv "
                           + "JOIN producto p ON dv.idproducto = p.id "
                           + "GROUP BY p.id, p.nombre "
                           + "ORDER BY total_vendido DESC";
                
                try (PreparedStatement ps = conn.prepareStatement(sql);
                     ResultSet rs = ps.executeQuery()) {
                    
                    int contador = 0;
                    int maxVentas = 0;
                    int minVentas = Integer.MAX_VALUE;
                    
                    while (rs.next()) {
                        contador++;
                        int idProducto = rs.getInt("id");
                        String nombreProducto = rs.getString("nombre");
                        int totalVendido = rs.getInt("total_vendido");
                        
                        // Determinar máximos y mínimos
                        if (contador == 1) maxVentas = totalVendido;
                        minVentas = Math.min(minVentas, totalVendido);
                        
                        // Añadir fila a la tabla
                        tabla.addCell(String.valueOf(contador));
                        tabla.addCell(nombreProducto);
                        tabla.addCell(String.valueOf(totalVendido));
                        
                        // Resaltar productos top y bottom
                        if (contador == 1) {
                            tabla.addCell(new Phrase("MÁS VENDIDO", 
                                  FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.GREEN)));
                        } else if (totalVendido == minVentas) {
                            tabla.addCell(new Phrase("MENOS VENDIDO", 
                                  FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.RED)));
                        } else {
                            tabla.addCell("");
                        }
                    }
                    
                    // Añadir resumen estadístico
                    Paragraph resumen = new Paragraph("\n\nResumen Estadístico:", 
                            FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14));
                    resumen.add("\nProducto más vendido: " + maxVentas + " unidades");
                    resumen.add("\nProducto menos vendido: " + minVentas + " unidades");
                    resumen.add("\nDiferencia: " + (maxVentas - minVentas) + " unidades");
                    
                    documento.add(tabla);
                    documento.add(resumen);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error en base de datos: " + e.getMessage(), 
                                             "Error", JOptionPane.ERROR_MESSAGE);
            }
            
            documento.close();
            abrirPDF(filePath); // Ahora este método existe
            JOptionPane.showMessageDialog(null, "Reporte de productos vendidos generado con éxito", 
                                         "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (DocumentException | FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error al generar PDF: " + e.getMessage(), 
                                         "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // AÑADE ESTE MÉTODO PARA SOLUCIONAR EL ERROR
    private void abrirPDF(String filePath) {
        try {
            File archivoPDF = new File(filePath);
            if (archivoPDF.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(archivoPDF);
                } else {
                    JOptionPane.showMessageDialog(null, 
                        "No se puede abrir el archivo automáticamente en este entorno", 
                        "Advertencia", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, 
                    "El archivo PDF no se encontró en: " + filePath, 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, 
                "Error al abrir el PDF: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, 
                "Error inesperado al abrir el PDF: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
