package Vista;

import Conexion.CreateConection;
import Modelo.Categorias;
import Controlador.ControllerUsuario;
import java.awt.Dimension;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GestionarUsuarios extends javax.swing.JInternalFrame {

    private final ControllerUsuario controlador = new ControllerUsuario();

    public GestionarUsuarios() {
        initComponents();
        this.setSize(new Dimension(798, 498));
        this.setTitle("Gestionar Categorias");
        this.CargarTablaCategorias();
         configurarSeleccionTabla();
         ImageIcon imagenOriginal = new ImageIcon("src/img/fondo3.jpg"); // Ruta corregida
        Image imagenEscalada = imagenOriginal.getImage().getScaledInstance(900, 500, Image.SCALE_SMOOTH); // Parámetros correctos
        lblWalpaper2.setIcon(new ImageIcon(imagenEscalada));
        this.repaint();
    }
private void configurarSeleccionTabla() {
   
    jTable_GestionarClientes.getSelectionModel().addListSelectionListener(e -> {
        if (!e.getValueIsAdjusting()) {
            int fila = jTable_GestionarClientes.getSelectedRow();
            
            if (fila >= 0) {
                // Índices corregidos:
                txtNombre.setText(jTable_GestionarClientes.getValueAt(fila, 1).toString()); // Columna 1: nombre
                txtApellido.setText(jTable_GestionarClientes.getValueAt(fila, 2).toString()); // Columna 2: apellido
                txtGmail.setText(jTable_GestionarClientes.getValueAt(fila, 3).toString()); // Columna 3: gmail
                txtTelefono.setText(jTable_GestionarClientes.getValueAt(fila, 4).toString()); // Columna 4: telefono
                txtDireccion.setText(jTable_GestionarClientes.getValueAt(fila, 5).toString()); // Columna 5: direccion
                txtPassword.setText(jTable_GestionarClientes.getValueAt(fila, 6).toString()); // Columna 5: direccion
                txtUsuario.setText(jTable_GestionarClientes.getValueAt(fila, 7).toString()); // Columna 5: direccion
            }
        }
    });
}
    private void limpiarCampos() {
        txtNombre.setText("");
        txtApellido.setText("");
        txtGmail.setText("");
        txtTelefono.setText("");
        txtDireccion.setText("");
        txtPassword.setText("");
        txtUsuario.setText("");

    }

    @SuppressWarnings("unchecked")
    protected void CargarTablaCategorias() {
         DefaultTableModel model = (DefaultTableModel) jTable_GestionarClientes.getModel();
    model.setRowCount(0);

    try (Connection conn = new CreateConection().getConnection()) {
        String sql = "SELECT idusuario, nombre, apellido, email, telefono, direccion, password, usuario FROM usuarios"; 
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("idusuario"), // Columna correcta: idusuario
                rs.getString("nombre"),
                rs.getString("apellido"),
                rs.getString("email"),   // Columna correcta: email (no gmail)
                rs.getString("telefono"),
                rs.getString("direccion"), 
                rs.getString("password"), 
                rs.getString("usuario") 
            });
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar usuarios: " + e.getMessage());
    }
}
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_GestionarClientes = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtGmail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtPassword = new javax.swing.JTextField();
        txtUsuario = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        lblWalpaper2 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Gestionar Usuarios");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable_GestionarClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Apellido", "Gmail", "Telefono", "Direccion", "Password", "Usuario"
            }
        ));
        jScrollPane1.setViewportView(jTable_GestionarClientes);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 730, 230));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 740, 250));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Nombre:");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        txtNombre.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel3.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 170, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Apellido:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, -1, -1));

        txtApellido.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel3.add(txtApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 30, 170, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Gmail:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 10, 50, -1));

        txtGmail.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel3.add(txtGmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 30, 170, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setText("Telefono:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        txtTelefono.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel3.add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 170, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setText("Direccion:");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 60, -1, -1));

        txtDireccion.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel3.add(txtDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, 170, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel7.setText("Password:");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 60, -1, -1));

        txtPassword.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel3.add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 80, 170, -1));

        txtUsuario.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel3.add(txtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 160, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel8.setText("Usuario");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btnActualizar.setBackground(new java.awt.Color(153, 255, 153));
        btnActualizar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(255, 153, 153));
        btnEliminar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(btnActualizar)
                .addGap(18, 18, 18)
                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnActualizar)
                    .addComponent(btnEliminar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 740, 170));

        lblWalpaper2.setText("jLabel9");
        getContentPane().add(lblWalpaper2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed

         int filaSeleccionada = jTable_GestionarClientes.getSelectedRow();

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Seleccione un usuario", "Error", JOptionPane.WARNING_MESSAGE);
        return;
    }

    int id = (int) jTable_GestionarClientes.getValueAt(filaSeleccionada, 0);
    String nombre = txtNombre.getText().trim();
    String apellido = txtApellido.getText().trim();
    String gmail = txtGmail.getText().trim();
    String telefono = txtTelefono.getText().trim();
    String direccion = txtDireccion.getText().trim();
    String password = txtPassword.getText().trim();
    String usuario = txtUsuario.getText().trim();

    // Validar campos vacíos
    if (nombre.isEmpty() || apellido.isEmpty() || gmail.isEmpty() || telefono.isEmpty() || direccion.isEmpty()||password.isEmpty()||usuario.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Complete todos los campos", "Error", JOptionPane.WARNING_MESSAGE);
        return;
    }

    try {
        if (controlador.actualizarUsuario(id, nombre, apellido, gmail, telefono, direccion,password,usuario)) {
            JOptionPane.showMessageDialog(this, "Usuario actualizado");
            CargarTablaCategorias();
            limpiarCampos();
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }

    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
       int filaSeleccionada = jTable_GestionarClientes.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Seleccione un usuario");
        return;
    }

    int id = (int) jTable_GestionarClientes.getValueAt(filaSeleccionada, 0);
    try {
        if (controlador.eliminarUsuario(id)) {
            JOptionPane.showMessageDialog(this, "usuario eliminado");
            CargarTablaCategorias();
            limpiarCampos();
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }

    }//GEN-LAST:event_btnEliminarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    public static javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable_GestionarClientes;
    private javax.swing.JLabel lblWalpaper2;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtGmail;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPassword;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables

}
