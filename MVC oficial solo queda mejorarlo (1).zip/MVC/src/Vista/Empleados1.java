/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package Vista;

import Controlador.EmpleadoController;
import Modelo.Empleados;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
///////////
import javax.swing.JTable;
import java.awt.Dimension;

public class Empleados1 extends javax.swing.JInternalFrame {

    private final EmpleadoController controlador = new EmpleadoController();

    public Empleados1() {
        initComponents();
        this.setSize(new Dimension(375, 456));
        this.setTitle("Empleado");
        jComboBoxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { 
    "Seleccione una opcion", 
    "activo", 
    "inactivo" 
}));
    }

    private void limpiarCampos() {
       txtnombre.setText("");
    txtApellido.setText("");
    txtPuesto.setText("");
    txtTelefono.setText("");
    txtdireccion.setText("");
    jComboBoxEstado.setSelectedIndex(0); // <-- ¡Corrección aquí!
    txtFecha.setText("");
    txtSalario.setText("");
    txtEmail.setText("");

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        insertar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtnombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtPuesto = new javax.swing.JTextField();
        txtdireccion = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtSalario = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jComboBoxEstado = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        lblwallpaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nombre:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        txtFecha.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 290, 140, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Apellido:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, -1, -1));

        insertar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        insertar.setText("Insertar");
        insertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertarActionPerformed(evt);
            }
        });
        getContentPane().add(insertar, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 380, -1, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Puesto:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("direccion:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("estado:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, -1, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("fecha Ingreso:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, -1, -1));

        txtnombre.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 190, -1));

        txtApellido.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 190, -1));

        txtPuesto.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 190, -1));

        txtdireccion.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtdireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 210, 190, -1));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nuevo Empleado");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, -1, -1));

        txtSalario.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 320, 140, -1));

        txtEmail.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 350, 140, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Salario:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, -1, -1));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Email:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, -1, -1));

        jComboBoxEstado.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jComboBoxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione una opcion", "activo", "inactivo" }));
        getContentPane().add(jComboBoxEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 250, 170, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Telefono:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));
        getContentPane().add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, 190, -1));

        lblwallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3.jpg"))); // NOI18N
        getContentPane().add(lblwallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 410));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void insertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertarActionPerformed

        if (txtnombre.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (txtApellido.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nit es obligatorio", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (txtPuesto.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El contacto es obligatorio", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (txtdireccion.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El direccion es obligatorio", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (jComboBoxEstado.getSelectedIndex() == 0) { // Verifica si seleccionó la opción default
        JOptionPane.showMessageDialog(this, "Debe seleccionar un estado", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
         boolean estado = jComboBoxEstado.getSelectedItem().toString().equalsIgnoreCase("activo");
        if (txtFecha.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "La telefono de contacto es obligatoria", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (txtSalario.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "La Salario de contacto es obligatoria", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
                double salario;
    try {
        // Permitir tanto punto como coma como separador decimal
        String salarioTexto = txtSalario.getText().replace(",", ".");
        salario = Double.parseDouble(salarioTexto);
        
        // Validar que sea positivo
        if (salario <= 0) {
            JOptionPane.showMessageDialog(this, "El salario debe ser mayor a 0", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, 
            "Formato de salario inválido\nEjemplo válido: 1500.50", 
            "Error", 
            JOptionPane.ERROR_MESSAGE);
        return;
    }

        if (txtEmail.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "La Email de contacto es obligatoria", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {

              controlador.agregarEmpleado(
            txtnombre.getText(),
            txtApellido.getText(),
            txtPuesto.getText(),
            txtTelefono.getText(),
            txtdireccion.getText(),
            estado, 
            txtFecha.getText(),
            salario, 
            txtEmail.getText()
        );
            JOptionPane.showMessageDialog(this, "Cliente agregado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            limpiarCampos(); // Limpiar los campos después de agregar
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        limpiarCampos();
    }//GEN-LAST:event_insertarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton insertar;
    private javax.swing.JComboBox<String> jComboBoxEstado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel lblwallpaper;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtPuesto;
    private javax.swing.JTextField txtSalario;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtdireccion;
    private javax.swing.JTextField txtnombre;
    // End of variables declaration//GEN-END:variables
}
