
package Vista;

import Conexion.CreateConection;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import javax.swing.JOptionPane;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
public class ReportesProductos {
     public void ReportesProductos() {
        String filePath = System.getProperty("user.home") + "/Desktop/Reporte_Productos.pdf";
        Document documento = new Document();
        try {
            PdfWriter.getInstance(documento, new FileOutputStream(filePath));

            Paragraph parrafo = new Paragraph();
            parrafo.setAlignment(Paragraph.ALIGN_CENTER);
            parrafo.setFont(FontFactory.getFont("Tahoma", 18, Font.BOLD, BaseColor.DARK_GRAY));
            parrafo.add("Reporte de Productos\n\n");
            parrafo.add("Generado por Sistema de Gestión\n\n");

            documento.open();
            documento.add(parrafo);
            
            PdfPTable tabla = new PdfPTable(7);
            tabla.setWidthPercentage(100);
            tabla.setWidths(new float[]{1, 3, 2, 2, 2, 2, 3}); // Ajuste de anchos de columna
            
            // Encabezados de tabla para productos
            tabla.addCell("ID");
            tabla.addCell("Nombre");
            tabla.addCell("Precio");
            tabla.addCell("Disponible");
            tabla.addCell("Stock");
            tabla.addCell("IVA (%)");
            tabla.addCell("Categoría");

            try (Connection conn = new CreateConection().getConnection()) {
                String sql = "SELECT id, nombre, precio, disponible, stock, iva, categoria FROM producto";
                try (PreparedStatement ps = conn.prepareStatement(sql);
                     ResultSet rs = ps.executeQuery()) {
                    
                    while (rs.next()) {
                        tabla.addCell(rs.getString("id"));
                        tabla.addCell(rs.getString("nombre"));
                        tabla.addCell(rs.getString("precio"));
                        tabla.addCell(rs.getBoolean("disponible") ? "Sí" : "No"); // Convertir booleano a texto
                        tabla.addCell(rs.getString("stock"));
                        tabla.addCell(rs.getString("iva") + "%");
                        tabla.addCell(rs.getString("categoria"));
                    }
                }
                documento.add(tabla);
            
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error en base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                System.err.println("Error en BD: " + e);
            }
            
            documento.close();
            
            // Abrir el PDF automáticamente
            abrirPDF(filePath);
            
            JOptionPane.showMessageDialog(null, 
                "Reporte de productos creado y abierto exitosamente", 
                "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (DocumentException | FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, 
                "Error al generar PDF: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
            System.err.println("Error en documento: " + e);
        }
    }
    
    // Método para abrir el PDF (el mismo que para usuarios)
    private void abrirPDF(String filePath) {
        try {
            File archivoPDF = new File(filePath);
            if (archivoPDF.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(archivoPDF);
                } else {
                    JOptionPane.showMessageDialog(null, 
                        "No se puede abrir el archivo automáticamente", 
                        "Advertencia", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, 
                    "El archivo PDF no se encontró:\n" + filePath, 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, 
                "Error al abrir el PDF: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
