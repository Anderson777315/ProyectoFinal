package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Conexion.CreateConection;
import Modelo.Usuario;

public class UsuarioDAO {
    private final CreateConection connFactory = new CreateConection();

    public List<Usuario> obtenerTodos() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM USUARIOS";

        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Usuario emp = new Usuario();
                emp.setId(rs.getInt("IDUSUARIO"));
                emp.setNombre(rs.getString("NOMBRE"));
                emp.setApellido(rs.getString("APELLIDO"));
                emp.setApellido(rs.getString("EMAIL"));
                emp.setApellido(rs.getString("TELEFONO"));
                emp.setApellido(rs.getString("DIRECCION"));
                emp.setUsuario(rs.getString("USUARIO"));
                emp.setPassword(rs.getString("PASSWORD"));
                
                lista.add(emp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public boolean guardar(Usuario emp) {
        String sql = "INSERT INTO USUARIOS (nombre, apellido,email,telefono,direccion, usuario, password) VALUES (?, ?, ?, ?, ?, ?,?)";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, emp.getNombre());
            ps.setString(2, emp.getApellido());
            ps.setString(3, emp.getEmail());
            ps.setString(4, emp.getTelefono());
            ps.setString(5, emp.getDireccion());
            ps.setString(6, emp.getUsuario());
            ps.setString(7, emp.getPassword());
           

            ps.executeUpdate();
            ps.close();
            conn.close();

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean actualizar(Usuario emp) {
        String sql = "UPDATE usuarios SET nombre=?, apellido=?, email=?, telefono=?, direccion=?, usuario=?, password=? WHERE idusuario=?";
    try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, emp.getNombre());
        ps.setString(2, emp.getApellido());
        ps.setString(3, emp.getEmail());
        ps.setString(4, emp.getTelefono());
        ps.setString(5, emp.getDireccion());
        ps.setString(6, emp.getUsuario());
        ps.setString(7, emp.getPassword());
        ps.setInt(8, emp.getId());
        return ps.executeUpdate() > 0; // Retorna true si se actualizó
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM USUARIOS WHERE IDUSUARIO=?";
    try (Connection conn = connFactory.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, id);
        return ps.executeUpdate() > 0; // ✅ Retorna true si se eliminó
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
}

