package dao;

import Modelo.Cabeceraventa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CabeceraVentaDAO {

    public int insertarCabeceraVenta(Connection conn, Cabeceraventa cabecera) throws SQLException {
       String sql = "INSERT INTO cabeceraventa(idcliente, idempleado, valorpagar, fechaventa, estado) "
                   + "VALUES (?, ?, ?, ?, ?) RETURNING id";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cabecera.getIdcliente());
            ps.setInt(2, cabecera.getIdempleado());
            ps.setDouble(3, cabecera.getValorpagar());
            ps.setString(4, cabecera.getFechaventa());
            ps.setInt(5, cabecera.getEstado());
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return -1;
    }
}
