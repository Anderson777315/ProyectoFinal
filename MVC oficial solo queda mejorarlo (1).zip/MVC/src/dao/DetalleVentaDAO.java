package dao;

import Modelo.Detalle_Venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DetalleVentaDAO {
  
    public boolean insertarDetalleVenta(Connection conn, Detalle_Venta detalle) throws SQLException {
        String sql = "INSERT INTO detalleventa(idventa, idproducto, cantidad, "
                   + "preciounitario, subtotal, descuento, iva, totalpagar, estado) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, detalle.getIdventa());
            ps.setInt(2, detalle.getIdproducto());
            ps.setInt(3, detalle.getCantidad());
            ps.setDouble(4, detalle.getPreciounitario());
            ps.setDouble(5, detalle.getSubtotal());
            ps.setDouble(6, detalle.getDescuento());
            ps.setDouble(7, detalle.getIva());
            ps.setDouble(8, detalle.getTotalpagar());
            ps.setInt(9, detalle.getEstado());
            
            int rows = ps.executeUpdate();
            return rows > 0;
        }
    }
}