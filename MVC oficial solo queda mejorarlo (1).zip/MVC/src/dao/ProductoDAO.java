package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Conexion.CreateConection;
import Modelo.Producto;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    private final CreateConection connFactory = new CreateConection();

    public List<Producto> obtenerTodos() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM producto";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Producto emp = new Producto(
                rs.getInt("id"),
    rs.getString("nombre"),
    rs.getDouble("precio"),
    rs.getInt("stock"),
    rs.getBoolean("disponible"),
    rs.getInt("iva"),
    rs.getString("categoria")
                );
                lista.add(emp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

public boolean actualizar(Producto pro) {
    String sql = "UPDATE producto SET nombre=?, precio=?, disponible=?, stock=?, iva=?, categoria=? WHERE id=?";
    try (Connection conn = connFactory.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, pro.getNombre());       
        ps.setDouble(2, pro.getPrecio());
        ps.setBoolean(3, pro.isDisponible()); // Disponible como booleano
        ps.setInt(4, pro.getStock()); 
        ps.setInt(5, pro.getPorcentajeIva()); 
        ps.setString(6, pro.getCategoria());
        ps

.setInt(7, pro.getId());

        ps.executeUpdate();
        return true;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }}

    public boolean eliminar(int id) {
        String sql = "DELETE FROM producto WHERE id=?";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean guardar(Producto pro) {
    String sql = "INSERT INTO producto (nombre, precio, stock, disponible, iva, categoria) VALUES (?, ?, ?, ?, ?, ?)";
    try (Connection conn = connFactory.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, pro.getNombre());
        ps.setDouble(2, pro.getPrecio());
        ps.setInt(3, pro.getStock());
        ps.setBoolean(4, pro.isDisponible());
        ps.setInt(5, pro.getPorcentajeIva());
        ps.setString(6, pro.getCategoria()); // Categoría como String

        ps.executeUpdate();
        return true;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
    public Producto obtenerProductoPorId(int idProducto) {
    String sql = "SELECT * FROM producto WHERE id = ?";
    try (Connection conn = connFactory.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setInt(1, idProducto);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return new Producto(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getDouble("precio"),
                rs.getInt("stock"),
                rs.getBoolean("disponible"),
                rs.getInt("iva"),
                rs.getString("categoria")
            );
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}
}
