/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
 import dao.ClienteDAO;
    import Modelo.Cliente;
    import java.util.List;

/**
 *
 * @author gabri
 */
public class ClientreController {
     private final ClienteDAO dao = new ClienteDAO();
    public List<Cliente> obtenerEmpleados (){
    return dao.obtenerTodos();
    }//constructor
    public void agregarCliente(String nombre, String apellido, String email,String telefono, String direccion){
    Cliente emp = new Cliente(0, nombre, apellido, email, telefono,direccion);
    dao.guardar (emp);
    }
    
    public void actualizarCliente(int id, String nombre, String apellido,  String email,String telefono, String direccion){
    Cliente emp = new Cliente (id, nombre, apellido, email, telefono,direccion);
    dao. actualizar (emp);
    }
    public void eliminarCliente(int id) {
    dao. eliminar (id);
}
    
}
    

