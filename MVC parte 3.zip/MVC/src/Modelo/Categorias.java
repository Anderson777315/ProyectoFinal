/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author JOSUE RAMOS
 */
public class Categorias {
    protected int idcategoria;
    protected String nombre;
    protected String descripcion;
    protected int estado;
    
    public Categorias(){
        this.idcategoria=0;
        this.nombre="";
        this.descripcion="";
        this.estado=0;
    }
        public Categorias(int idcatecoria, String nombre, String descripsion, int estado){
        this.idcategoria=idcatecoria;
        this.nombre=nombre;
        this.descripcion=descripsion;
        this.estado=estado;
    }

    public int getIdcategoria() {
        return idcategoria;
    }

    public void setIdcategoria(int idcategoria) {
        this.idcategoria = idcategoria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

  
        
}
         
