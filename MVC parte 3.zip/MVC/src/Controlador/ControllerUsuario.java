/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import dao.UsuarioDAO;
import Conexion.CreateConexion1;
import java.sql.Connection;
import Modelo.Usuario;
import java.sql.Statement; 
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

public class ControllerUsuario {
    //metodo inicair secion

    public boolean loginUser(Usuario objeto) {

        boolean respuesta = false;
        Connection cn = CreateConexion1.getCreateConexion1();
        String sql = "select usuario, password from usuarios where usuario ='" + objeto.getUsuario() + "' and password = '" + objeto.getPassword() + "'";
        Statement st;
        try {
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                respuesta = true;
            }
            rs.close();
            st.close();
            cn.close();
        } catch (SQLException e) {
            System.out.println("Eroro al Iniciar Sesion");
            JOptionPane.showMessageDialog(null, "Erro al Iniciar Sesion");
        }
        return respuesta;
    }
    private final UsuarioDAO dao = new UsuarioDAO();

    public List<Usuario> obtenerUsuario() {
        return dao.obtenerTodos();
    }//constructor

    public void agregarUsuario(String nombre, String apellido, String email, String telefono, String direccion, String passwrod, String usuario) {
        Usuario emp = new Usuario(0, nombre, apellido, email, telefono, direccion, usuario, passwrod);
        dao.guardar(emp);
    }

    public boolean actualizarUsuario(int id, String nombre, String apellido, String email, String telefono, String direccion, String passwrod, String usuario) {
        Usuario emp = new Usuario(id, nombre, apellido, email, telefono, direccion, usuario, passwrod);
        return dao.actualizar(emp); // Retorna el resultado del DAO
    }

    public boolean eliminarUsuario(int id) {
        return dao.eliminar(id);
    }
}
