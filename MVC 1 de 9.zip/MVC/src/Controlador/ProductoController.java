package Controlador;

import dao.ProductoDAO;
import Modelo.Producto;
import java.util.List;

public class ProductoController {
    private final ProductoDAO dao = new ProductoDAO();
    public List<Producto> obtenerProductos() {
        return dao.obtenerTodos();
    }

    public void agregarProducto(String nombre, String categoria, double precio, int stock, boolean disponible, int porcentajeIva) {
        Producto p = new Producto(0, nombre, categoria, precio, stock, disponible,porcentajeIva);
        dao.guardar(p);
    }

    public void actualizarProducto(int id, String nombre, String categoria, double precio, int stock, boolean disponible, int porcentajeIva) {
        Producto p = new Producto(id, nombre, categoria, precio, stock, disponible,porcentajeIva);
        dao.actualizar(p);
    }

    public void eliminarProducto(int id) {
        dao.eliminar(id);
    }
}
