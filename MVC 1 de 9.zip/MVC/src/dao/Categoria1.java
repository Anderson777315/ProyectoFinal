/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;


import Conexion.CreateConection;
import Modelo.Categorias;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Categoria1 {
    private final CreateConection connFactory = new CreateConection();

    public List<Categorias> obtenerTodos() {
        List<Categorias> lista = new ArrayList<>();
        String sql = "SELECT * FROM CATEGORIAS";

        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Categorias cli = new Categorias(
                    rs.getInt("ID"),
                    rs.getString("DESCRIPCION"),
                    rs.getString("NOMBRE"),
                    rs.getInt("ESTADO") // Corregido a getInt
                );
                lista.add(cli);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean guardar(Categorias cli) {
        String sql = "INSERT INTO CATEGORIAS (descripcion, nombre, estado) VALUES (?, ?, ?)";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cli.getDescripcion());
            ps.setString(2, cli.getNombre());
            ps.setInt(3, cli.getEstado()); // Corregido a setInt

            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean actualizar(Categorias cli) {
        String sql = "UPDATE categorias SET descripcion=?, nombre=?, estado=? WHERE ID=?";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cli.getDescripcion());
            ps.setString(2, cli.getNombre());
            ps.setInt(3, cli.getEstado()); // Corregido a setInt
            ps.setInt(4, cli.getIdcategoria()); // Corregido a getIdcategoria()

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

   public boolean eliminar(int id) {
    String sql = "DELETE FROM CATEGORIAS WHERE ID=?";
    try (Connection conn = connFactory.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, id);
        ps.executeUpdate();
        return true;
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false;
}
}
