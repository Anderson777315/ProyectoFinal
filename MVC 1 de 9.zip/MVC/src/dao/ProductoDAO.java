package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Conexion.CreateConection;
import Modelo.Producto;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    private final CreateConection connFactory = new CreateConection();

    public List<Producto> obtenerTodos() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM producto";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Producto emp = new Producto(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("categoria"),
                    rs.getDouble("precio"),
                    rs.getInt("stock"),
                    rs.getBoolean("disponible"),
                        rs.getInt("iva")
                );
                lista.add(emp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean guardar(Producto emp) {
        String sql = "INSERT INTO producto (nombre, categoria, precio, stock, disponible,iva) VALUES (?, ?, ?, ?, ?,?)";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emp.getNombre());
            ps.setString(2, emp.getCategoria());
            ps.setDouble(3, emp.getPrecio());
            ps.setInt(4, emp.getStock());
            ps.setBoolean(5, emp.isDisponible());
            ps.setInt(6, emp.getPorcentajeIva());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean actualizar(Producto emp) {
        String sql = "UPDATE producto SET nombre=?, categoria=?, precio=?, stock=?, disponible=?, iva=? WHERE id=?";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emp.getNombre());
            ps.setString(2, emp.getCategoria());
            ps.setDouble(3, emp.getPrecio());
            ps.setInt(4, emp.getStock());
            ps.setBoolean(5, emp.isDisponible());
            ps.setInt(6, emp.getPorcentajeIva());
            ps.setInt(7, emp.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM producto WHERE id=?";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
