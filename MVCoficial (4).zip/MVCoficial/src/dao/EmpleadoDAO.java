package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Conexion.CreateConection;
import Modelo.Empleados;

public class EmpleadoDAO {
    private final CreateConection connFactory = new CreateConection();

     public List<Empleados> obtenerTodos() {
        List<Empleados> lista = new ArrayList<>();
        String sql = "SELECT * FROM empleado"; // Asegurar nombre de tabla

        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Empleados emp = new Empleados(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("puesto"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getBoolean("estado"),
                    rs.getString("fecha"),
                    rs.getDouble("salario"),
                    rs.getString("email") // Nombre de columna corregido
                );
                lista.add(emp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean guardar(Empleados emp) {
        String sql = "INSERT INTO empleado (nombre, apellido, puesto, telefono, direccion, estado, fecha, salario, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, emp.getNombre());
            ps.setString(2, emp.getApellido());
            ps.setString(3, emp.getPuesto());
            ps.setString(4, emp.getTelefono());
            ps.setString(5, emp.getDireccion());
            ps.setBoolean(6, emp.isEstado());
            ps.setString(7, emp.getFecha());
            ps.setDouble(8, emp.getSalario());
            ps.setString(9, emp.getEmail());

            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean actualizar(Empleados emp) {
        String sql = "UPDATE empleado SET nombre=?, apellido=?, puesto=?, telefono=?, direccion=?, estado=?, fecha=?, salario=?, email=? WHERE id=?";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, emp.getNombre());
            ps.setString(2, emp.getApellido());
            ps.setString(3, emp.getPuesto());
            ps.setString(4, emp.getTelefono());
            ps.setString(5, emp.getDireccion());
            ps.setBoolean(6, emp.isEstado());
            ps.setString(7, emp.getFecha());
            ps.setDouble(8, emp.getSalario());
            ps.setString(9, emp.getEmail());
            ps.setInt(10, emp.getId());

            int rowsUpdated = ps.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM empleado WHERE id=?";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            int rowsDeleted = ps.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
      public Empleados obtenerPorId(int id) {
        String sql = "SELECT * FROM empleado WHERE id = ?";
        try (Connection conn = new CreateConection().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return new Empleados(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("puesto"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getBoolean("estado"),
                    rs.getString("fecha"),
                    rs.getDouble("salario"),
                    rs.getString("email")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}

