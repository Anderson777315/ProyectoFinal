package Vista;

import Conexion.CreateConection;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import javax.swing.JOptionPane;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Reporteporfecha {

    public void generarReporteVentasPorFecha(Date fechaInicio, Date fechaFin) {
        File tempFile = null;
        try {
            // Crear archivo temporal
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            String prefix = "Reporte_Ventas_" + sdf.format(fechaInicio) + "a" + sdf.format(fechaFin) + "_";
            tempFile = File.createTempFile(prefix, ".pdf");
            tempFile.deleteOnExit();  // Se eliminará automáticamente al salir
            
            Document documento = new Document(PageSize.A4.rotate()); // Formato horizontal
            try {
                PdfWriter.getInstance(documento, new FileOutputStream(tempFile));
                documento.open();

                // Formatear fechas para mostrar en el reporte
                SimpleDateFormat fmtFecha = new SimpleDateFormat("dd/MM/yyyy");
                String strFechaInicio = fmtFecha.format(fechaInicio);
                String strFechaFin = fmtFecha.format(fechaFin);

                // Título del reporte
                Paragraph titulo = new Paragraph("REPORTE DE VENTAS POR FECHA", 
                        FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20, BaseColor.DARK_GRAY));
                titulo.setAlignment(Element.ALIGN_CENTER);
                titulo.setSpacingAfter(5f);
                
                // Rango de fechas
                Paragraph rangoFechas = new Paragraph(
                        "Del " + strFechaInicio + " al " + strFechaFin, 
                        FontFactory.getFont(FontFactory.HELVETICA, 14, BaseColor.BLUE)
                );
                rangoFechas.setAlignment(Element.ALIGN_CENTER);
                rangoFechas.setSpacingAfter(20f);

                documento.add(titulo);
                documento.add(rangoFechas);

                // Tabla de ventas
                PdfPTable tabla = new PdfPTable(8);
                tabla.setWidthPercentage(100);
                tabla.setWidths(new float[]{1, 2, 3, 3, 2, 2, 2, 2});
                
                // Encabezados de tabla
                String[] encabezados = {
                    "ID Venta", "Fecha", "Cliente", "Vendedor", 
                    "Total Venta", "Productos", "Estado", "Detalles"
                };
                
                for (String enc : encabezados) {
                    tabla.addCell(new Phrase(enc, FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
                }

                // Variables para estadísticas
                double totalGeneral = 0;
                int totalVentas = 0;
                int totalProductos = 0;

                try (Connection conn = new CreateConection().getConnection()) {
                    // Consulta principal de ventas
                    String sql = "SELECT cv.id, cv.fechaventa, cv.valorpagar, cv.estado, "
                               + "c.nombre AS cliente, e.nombre AS vendedor "
                               + "FROM cabeceraventa cv "
                               + "JOIN cliente c ON cv.idcliente = c.id "
                               + "JOIN empleado e ON cv.idempleado = e.id "
                               + "WHERE cv.fechaventa BETWEEN ? AND ? "
                               + "ORDER BY cv.fechaventa DESC";
                    
                    try (PreparedStatement ps = conn.prepareStatement(sql)) {
                        // Convertir fechas al formato de la BD (asumiendo formato YYYY-MM-DD)
                        SimpleDateFormat sdfBD = new SimpleDateFormat("yyyy-MM-dd");
                        ps.setString(1, sdfBD.format(fechaInicio));
                        ps.setString(2, sdfBD.format(fechaFin));
                        
                        try (ResultSet rs = ps.executeQuery()) {
                            while (rs.next()) {
                                int idVenta = rs.getInt("id");
                                String fecha = rs.getString("fechaventa");
                                double total = rs.getDouble("valorpagar");
                                int estado = rs.getInt("estado");
                                String cliente = rs.getString("cliente");
                                String vendedor = rs.getString("vendedor");
                                
                                // Obtener detalles de productos para esta venta
                                int cantProductos = obtenerCantidadProductos(conn, idVenta);
                                
                                // Agregar fila a la tabla
                                tabla.addCell(String.valueOf(idVenta));
                                tabla.addCell(fecha);
                                tabla.addCell(cliente);
                                tabla.addCell(vendedor);
                                tabla.addCell(String.format("$%,.2f", total));
                                tabla.addCell(String.valueOf(cantProductos));
                                tabla.addCell(estado == 1 ? "ACTIVA" : "ANULADA");
                                tabla.addCell("Ver detalle");
                                
                                // Actualizar estadísticas
                                totalGeneral += total;
                                totalVentas++;
                                totalProductos += cantProductos;
                            }
                        }
                    }
                    
                    documento.add(tabla);
                    
                    // Resumen estadístico
                    Paragraph resumen = new Paragraph("\n\nRESUMEN ESTADÍSTICO\n", 
                            FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16));
                    resumen.add("Total de ventas: " + totalVentas + "\n");
                    resumen.add("Productos vendidos: " + totalProductos + "\n");
                    resumen.add("Valor total vendido: " + String.format("$%,.2f", totalGeneral) + "\n");
                    resumen.add("Promedio por venta: " + 
                            (totalVentas > 0 ? String.format("$%,.2f", totalGeneral / totalVentas) : "$0.00"));
                    
                    resumen.setSpacingBefore(20f);
                    documento.add(resumen);
                    
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, 
                        "Error en base de datos: " + e.getMessage(), 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
                
                documento.close();
                abrirPDF(tempFile.getAbsolutePath());
                JOptionPane.showMessageDialog(null, 
                    "Reporte de ventas generado exitosamente", 
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
                
            } catch (DocumentException | FileNotFoundException e) {
                JOptionPane.showMessageDialog(null, 
                    "Error al generar PDF: " + e.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, 
                "Error al crear archivo temporal: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Método auxiliar para obtener cantidad de productos por venta
    private int obtenerCantidadProductos(Connection conn, int idVenta) throws SQLException {
        String sql = "SELECT SUM(cantidad) AS total_productos "
                   + "FROM detalleventa "
                   + "WHERE idventa = ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idVenta);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total_productos");
                }
            }
        }
        return 0;
    }
    
    // Método para abrir el PDF
    private void abrirPDF(String filePath) {
        try {
            File archivoPDF = new File(filePath);
            if (archivoPDF.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(archivoPDF);
                } else {
                    JOptionPane.showMessageDialog(null, 
                        "No se puede abrir el archivo automáticamente", 
                        "Advertencia", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, 
                    "El archivo PDF no se encontró:\n" + filePath, 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, 
                "Error al abrir el PDF: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Método para mostrar un diálogo de selección de fechas
    public void mostrarDialogoReporteVentas() {
        // Implementar con componentes de fecha
        Date fechaInicio = new Date(System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000)); // Hace 7 días
        Date fechaFin = new Date(); // Hoy
        generarReporteVentasPorFecha(fechaInicio, fechaFin);
    }
}