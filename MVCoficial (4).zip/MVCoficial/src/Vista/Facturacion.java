
package Vista;

import java.awt.Dimension;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import Conexion.CreateConection;
import Controlador.VentaPDF;
import Controlador.registrarVentaCompleta;
import Modelo.Cabeceraventa;
import Modelo.Detalle_Venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
public class Facturacion extends javax.swing.JInternalFrame {
ArrayList<Detalle_Venta> listaProductos = new ArrayList<>();
    protected Detalle_Venta producto;
    protected DefaultTableModel modeloDatosProductos;
    protected int iddetalle = 0;
    protected int idproducto = 0;
    protected String nombre = "";
    protected int cantidadproducto = 0;
    protected double preciounitario = 0.0;
    protected int porcentajeIva = 0;
    protected int cantidad = 0;
    protected double subtotal = 0.0;
    protected double descuento = 0.0;
    protected double iva = 0.0;
    protected double totalPagar = 0.0;
    private int auxidDETALLE = 1;
    
    // Mapa para almacenar IDs de productos (nombre -> id)
    private java.util.Map<String, Integer> productoMap = new java.util.HashMap<>();
        
        
    public Facturacion() {
       initComponents();
        
        // Inicializar fecha actual
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        txtFecha.setText(sdf.format(new Date()));
        
        modeloDatosProductos = new DefaultTableModel(
                new Object[][]{},
                new String[]{"N", "Nombre", "Cantidad", "P. Unitario", "Sub. Total", "Descuento", "Iva", "Total Pagar", "Accion"}
        );
        
        jTable_productos.setModel(modeloDatosProductos);
        ImageIcon imagenOriginal = new ImageIcon("src/img/fondo3.jpg");
        Image imagenEscalada = imagenOriginal.getImage().getScaledInstance(800, 600, Image.SCALE_SMOOTH);
        lblWalpaper.setIcon(new ImageIcon(imagenEscalada));
        this.repaint();
        this.setTitle("Facturacion");
        this.CargarClientes();
        this.cargarEmpleado();
        this.cargarProductos();
         // Seleccionar el primer ítem en los combos
    jComboBoxcliente2.setSelectedIndex(0);
    jComboBoxUsuario.setSelectedIndex(0);
    jComboBoxproducto.setSelectedIndex(0);
        jComboBoxcliente2.addActionListener(e -> asignarIdCliente());
    jComboBoxUsuario.addActionListener(e -> asignarIdUsuario());
        // Validar que solo se ingresen números en cantidad
        txtCantidad.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                }
            }
        });
        
        // Validar que solo se ingresen números en efectivo
        txtEfectivo.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!(Character.isDigit(c) || c == '.')) {
                    e.consume();
                }
            }
        });
        
        jTable_productos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_productosMouseClicked(evt);
            }
        });
    }

    private void listTablaProductos() {

        this.modeloDatosProductos.setRowCount(0);
        for (int i = 0; i < listaProductos.size(); i++) {
            Detalle_Venta detalle = listaProductos.get(i);
            modeloDatosProductos.addRow(new Object[]{
                i + 1,
                detalle.getNombre(),
                detalle.getCantidad(),
                detalle.getPreciounitario(),
                detalle.getSubtotal(),
                detalle.getDescuento(),
                detalle.getIva(),
                detalle.getTotalpagar(),
                "Eliminar"
            });
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jComboBoxproducto = new javax.swing.JComboBox<>();
        jComboBoxUsuario = new javax.swing.JComboBox<>();
        txtCantidad = new javax.swing.JTextField();
        txtUsuariobuscar = new javax.swing.JTextField();
        btnBuscarcliente = new javax.swing.JButton();
        btnBuscarusuario = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_productos = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jComboBoxcliente2 = new javax.swing.JComboBox<>();
        txtClientebuscar2 = new javax.swing.JTextField();
        btnAñadirproducto = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtIdusuario = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtIdcliente = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtCambio = new javax.swing.JTextField();
        txtDescuento = new javax.swing.JTextField();
        txtIva = new javax.swing.JTextField();
        txtTotalpagar = new javax.swing.JTextField();
        txtEfectivo = new javax.swing.JTextField();
        txtSubtotal = new javax.swing.JTextField();
        btnCalcularcambio = new javax.swing.JButton();
        btnRegistarventa = new javax.swing.JButton();
        lblWalpaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Facturación");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 0, 140, 20));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Fecha del Registro:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Cantidad:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 70, -1, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Usuario;");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        jComboBoxproducto.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jComboBoxproducto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione producto:", "Item 2", "Item 3", "Item 4" }));
        getContentPane().add(jComboBoxproducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 230, -1));

        jComboBoxUsuario.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jComboBoxUsuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione Usurio:", "Item 2", "Item 3", "Item 4" }));
        getContentPane().add(jComboBoxUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 130, 230, -1));

        txtCantidad.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 70, 120, -1));

        txtUsuariobuscar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtUsuariobuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 130, 190, -1));

        btnBuscarcliente.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnBuscarcliente.setText("Buscar Cliente");
        btnBuscarcliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarclienteActionPerformed(evt);
            }
        });
        getContentPane().add(btnBuscarcliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 40, -1, -1));

        btnBuscarusuario.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnBuscarusuario.setText("Buscar Usuario");
        btnBuscarusuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarusuarioActionPerformed(evt);
            }
        });
        getContentPane().add(btnBuscarusuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 130, -1, -1));

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable_productos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "N", "Nombre", "Cantidad", "P. Unitario", "Sub. Total", "Descuento", "Iva", "Total Pagar", "Accion"
            }
        ));
        jTable_productos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_productosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable_productos);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 720, 130));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 740, 150));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Producto:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        txtFecha.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtFecha.setEnabled(false);
        getContentPane().add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 170, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Cliente:\n");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        jComboBoxcliente2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jComboBoxcliente2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione cliente:", "Item 2", "Item 3", "Item 4" }));
        getContentPane().add(jComboBoxcliente2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, 230, -1));

        txtClientebuscar2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtClientebuscar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 40, 190, -1));

        btnAñadirproducto.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnAñadirproducto.setText("Añadir Producto");
        btnAñadirproducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAñadirproductoActionPerformed(evt);
            }
        });
        getContentPane().add(btnAñadirproducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 70, -1, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Id Usuario:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 100, -1, -1));

        txtIdusuario.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtIdusuario.setEnabled(false);
        txtIdusuario.setPreferredSize(new java.awt.Dimension(70, 21));
        getContentPane().add(txtIdusuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 100, -1, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Id Cliente:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 100, -1, -1));

        txtIdcliente.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtIdcliente.setEnabled(false);
        txtIdcliente.setPreferredSize(new java.awt.Dimension(70, 21));
        txtIdcliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdclienteActionPerformed(evt);
            }
        });
        getContentPane().add(txtIdcliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 100, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel9.setText("Descuento:");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel10.setText("Iva:");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, -1, -1));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel11.setText("Total a pagar:");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel12.setText("Efectivo:");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel13.setText("Cambio:");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, -1, -1));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel14.setText("Subtotal:");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, -1));

        txtCambio.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtCambio.setEnabled(false);
        jPanel2.add(txtCambio, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, 120, -1));

        txtDescuento.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtDescuento.setEnabled(false);
        jPanel2.add(txtDescuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, 130, -1));

        txtIva.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtIva.setEnabled(false);
        jPanel2.add(txtIva, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 130, 20));

        txtTotalpagar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtTotalpagar.setEnabled(false);
        txtTotalpagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalpagarActionPerformed(evt);
            }
        });
        jPanel2.add(txtTotalpagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 130, -1));

        txtEfectivo.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel2.add(txtEfectivo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 120, -1));

        txtSubtotal.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtSubtotal.setEnabled(false);
        jPanel2.add(txtSubtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, 130, -1));

        btnCalcularcambio.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnCalcularcambio.setText("Calcular Cambio");
        btnCalcularcambio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularcambioActionPerformed(evt);
            }
        });
        jPanel2.add(btnCalcularcambio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 120, 40));

        btnRegistarventa.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnRegistarventa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/impresora.png"))); // NOI18N
        btnRegistarventa.setText("Registar Venta");
        btnRegistarventa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistarventaActionPerformed(evt);
            }
        });
        jPanel2.add(btnRegistarventa, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 160, 40));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 320, 340, 240));

        lblWalpaper.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(lblWalpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarclienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarclienteActionPerformed
       String telefono = txtClientebuscar2.getText().trim();

    try (Connection conn = new CreateConection().getConnection()) {
        PreparedStatement ps;
        
        if (telefono.isEmpty()) {
            // Si no hay teléfono, cargar todos los clientes
            ps = conn.prepareStatement("SELECT id, nombre, apellido FROM cliente");
        } else {
            // Si hay teléfono, buscar por teléfono
            ps = conn.prepareStatement("SELECT id, nombre, apellido FROM cliente WHERE telefono = ?");
            ps.setString(1, telefono);
        }

        try (ResultSet rs = ps.executeQuery()) {
            jComboBoxcliente2.removeAllItems();
            jComboBoxcliente2.addItem("Seleccione cliente:");

            boolean encontrado = false;
            String clienteEncontrado = null;
            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String apellido = rs.getString("apellido");
                String cliente = nombre + " " + apellido;
                jComboBoxcliente2.addItem(cliente);
                
                if (!telefono.isEmpty()) {
                    // Guardar el primer cliente encontrado para seleccionarlo
                    if (!encontrado) {
                        clienteEncontrado = cliente;
                        txtIdcliente.setText(rs.getString("id"));
                        encontrado = true;
                    }
                }
            }
            
            // Si se encontró un cliente específico, seleccionarlo en el combo
            if (encontrado && clienteEncontrado != null) {
                jComboBoxcliente2.setSelectedItem(clienteEncontrado);
            }
            
            if (!telefono.isEmpty() && !encontrado) {
                JOptionPane.showMessageDialog(this, "Cliente no encontrado");
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error en la base de datos: " + e.getMessage());
    }                 
                                                             
    }//GEN-LAST:event_btnBuscarclienteActionPerformed

    private void btnRegistarventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistarventaActionPerformed
    if (jComboBoxcliente2.getSelectedIndex() <= 0) {
        JOptionPane.showMessageDialog(this, "Seleccione un cliente válido");
        return;
    }
    
    if (jComboBoxUsuario.getSelectedIndex() <= 0) {
        JOptionPane.showMessageDialog(this, "Seleccione un usuario válido");
        return;
    }
    
    if (listaProductos.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Añada al menos un producto");
        return;
    }

    // Validar campos numéricos
    String idClienteText = txtIdcliente.getText().trim();
    String idUsuarioText = txtIdusuario.getText().trim();
    String totalText = txtTotalpagar.getText().replace("Q.", "").trim();
    
    if (idClienteText.isEmpty() || idUsuarioText.isEmpty() || totalText.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Complete todos los campos obligatorios");
        return;
    }

    try {
        // Obtener datos del formulario
        int idCliente = Integer.parseInt(idClienteText);
        int idUsuario = Integer.parseInt(idUsuarioText);
        double total = Double.parseDouble(totalText);
        String fecha = txtFecha.getText();

        // Crear objeto cabecera
        Cabeceraventa cabecera = new Cabeceraventa();
        cabecera.setIdcliente(idCliente);
        cabecera.setIdempleado(idUsuario);
        cabecera.setValorpagar(total);
        cabecera.setFechaventa(fecha);
        cabecera.setEstado(1); // Estado activo

        // Registrar venta
        registrarVentaCompleta control = new registrarVentaCompleta();
        if (control.registrarVenta(cabecera, listaProductos)) {
            JOptionPane.showMessageDialog(this, "Venta registrada con éxito!");
            // Generar la factura de venta
            VentaPDF pdf=new VentaPDF();
            pdf.DatosCliente(idCliente);
            pdf.generarFacturaPDF();
            // Limpiar después del registro exitoso
            listaProductos.clear();
            modeloDatosProductos.setRowCount(0);
            actualizarTotales();
            txtEfectivo.setText("");
            txtCambio.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar la venta");
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Error en formato numérico: " + e.getMessage());
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        e.printStackTrace();
    }                   
                    
    }//GEN-LAST:event_btnRegistarventaActionPerformed

    private void txtIdclienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdclienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdclienteActionPerformed

    private void btnBuscarusuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarusuarioActionPerformed
      String telefono = txtUsuariobuscar.getText().trim();

    try (Connection conn = new CreateConection().getConnection()) {
        PreparedStatement ps;
        
        if (telefono.isEmpty()) {
            // Si no hay teléfono, cargar todos los usuarios
            ps = conn.prepareStatement("SELECT id, nombre, apellido FROM empleado");
        } else {
            // Si hay teléfono, buscar por teléfono
            ps = conn.prepareStatement("SELECT id, nombre, apellido FROM empleado WHERE telefono = ?");
            ps.setString(1, telefono);
        }

        try (ResultSet rs = ps.executeQuery()) {
            jComboBoxUsuario.removeAllItems();
            jComboBoxUsuario.addItem("Seleccione empleado:");

            boolean encontrado = false;
            String usuarioEncontrado = null;
            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String apellido = rs.getString("apellido");
                String usuario = nombre + " " + apellido;
                jComboBoxUsuario.addItem(usuario);
                
                if (!telefono.isEmpty()) {
                    // Guardar el primer usuario encontrado para seleccionarlo
                    if (!encontrado) {
                        usuarioEncontrado = usuario;
                        txtIdusuario.setText(rs.getString("id"));
                        encontrado = true;
                    }
                }
            }
            
            // Si se encontró un usuario específico, seleccionarlo en el combo
            if (encontrado && usuarioEncontrado != null) {
                jComboBoxUsuario.setSelectedItem(usuarioEncontrado);
            }
            
            if (!telefono.isEmpty() && !encontrado) {
                JOptionPane.showMessageDialog(this, "Empleado no encontrado");
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error en la base de datos: " + e.getMessage());
    }         
         
    }//GEN-LAST:event_btnBuscarusuarioActionPerformed

    private void btnAñadirproductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAñadirproductoActionPerformed
    if (jComboBoxproducto.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto válido", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String cantidadTexto = txtCantidad.getText().trim();
        if (cantidadTexto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese la cantidad", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!esNumerico(cantidadTexto)) {
            JOptionPane.showMessageDialog(this, "Solo se permiten valores numéricos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int cantidad = Integer.parseInt(cantidadTexto);
        DatosDelProducto(); // Obtener precio, stock e IVA

        if (cantidad <= 0) {
            JOptionPane.showMessageDialog(this, "Cantidad debe ser mayor a cero", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (cantidad > cantidadproducto) {
            JOptionPane.showMessageDialog(this, 
                "La cantidad solicitada (" + cantidad + ") excede el stock disponible (" + cantidadproducto + ")",
                "Stock Insuficiente", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Calcular valores
        double subtotal = preciounitario * cantidad;
        double ivaMonto = subtotal * (porcentajeIva / 100.0);
        double total = subtotal + ivaMonto;

        // Añadir a la lista y tabla
        Detalle_Venta detalle = new Detalle_Venta(
                auxidDETALLE, 0, idproducto, nombre, cantidad,
                preciounitario, subtotal, 0.0, ivaMonto, total, 1
        );
        listaProductos.add(detalle);
        auxidDETALLE++;

        listTablaProductos(); // Actualizar tabla
        actualizarTotales(); // Actualizar totales
        txtCantidad.setText(""); // Limpiar campo
    
    
    }//GEN-LAST:event_btnAñadirproductoActionPerformed

    private void txtTotalpagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalpagarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalpagarActionPerformed

    private void btnCalcularcambioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularcambioActionPerformed
String totalText = txtTotalpagar.getText().replace("Q.", "").trim();
        String efectivoText = txtEfectivo.getText().trim();
        
        if (totalText.isEmpty() || efectivoText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese el total y el efectivo", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validar formato numérico
        if (!totalText.matches("\\d+(\\.\\d{1,2})?") || !efectivoText.matches("\\d+(\\.\\d{1,2})?")) {
            JOptionPane.showMessageDialog(this, "Formato numérico inválido. Use formato: 150.50", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            double total = Double.parseDouble(totalText);
            double efectivo = Double.parseDouble(efectivoText);
            
            if (efectivo < total) {
                JOptionPane.showMessageDialog(this, 
                    "El efectivo es menor que el total a pagar", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE
                );
            } else {
                double cambio = efectivo - total;
                txtCambio.setText(String.format("Q.%.2f", cambio));
                JOptionPane.showMessageDialog(this, 
                    "Pago aceptado. Cambio: Q." + String.format("%.2f", cambio), 
                    "Éxito", 
                    JOptionPane.INFORMATION_MESSAGE
                );
            }
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Error en el formato numérico: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE
            );
        }
    
    }//GEN-LAST:event_btnCalcularcambioActionPerformed

    private void jTable_productosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_productosMouseClicked
      int column = jTable_productos.getColumnModel().getColumnIndexAtX(evt.getX());
        int row = jTable_productos.rowAtPoint(evt.getPoint());
        
        if (column == 8) { 
            String nombreProducto = jTable_productos.getValueAt(row, 1).toString(); 
            
            int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Desea eliminar el producto: " + nombreProducto + "?",
                "Confirmar Eliminación",
                JOptionPane.YES_NO_OPTION
            );
            
            if (respuesta == JOptionPane.YES_OPTION) {
                listaProductos.remove(row);
                listTablaProductos();
                actualizarTotales();
                
                for (int i = 0; i < modeloDatosProductos.getRowCount(); i++) {
                    modeloDatosProductos.setValueAt(i + 1, i, 0);
                }
            }
        }
      
    }//GEN-LAST:event_jTable_productosMouseClicked
//protected void CargarClientes() throws SQLException{
 protected void CargarClientes() {
      try (Connection conn = new CreateConection().getConnection();
         PreparedStatement ps = conn.prepareStatement("SELECT id, nombre, apellido FROM cliente");
         ResultSet rs = ps.executeQuery()) {
        
        jComboBoxcliente2.removeAllItems();
        jComboBoxcliente2.addItem("Seleccione cliente:");

        while (rs.next()) {
            String nombreCompleto = rs.getString("nombre") + " " + rs.getString("apellido");
            jComboBoxcliente2.addItem(nombreCompleto);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar clientes: " + e.getMessage());
    }
    }

    protected void cargarEmpleado() {
          try (Connection conn = new CreateConection().getConnection();
         PreparedStatement ps = conn.prepareStatement("SELECT id, nombre, apellido FROM empleado");
         ResultSet rs = ps.executeQuery()) {
        
        jComboBoxUsuario.removeAllItems();
        jComboBoxUsuario.addItem("Seleccione empleado:");

        while (rs.next()) {
            String nombreCompleto = rs.getString("nombre") + " " + rs.getString("apellido");
            jComboBoxUsuario.addItem(nombreCompleto);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar empleado: " + e.getMessage());
    }
    }

    protected void cargarProductos() {
        productoMap.clear(); // Limpiar mapa antes de cargar
        
        try (Connection conn = new CreateConection().getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT id, nombre, precio, stock, iva FROM producto");
             ResultSet rs = ps.executeQuery()) {
            
            jComboBoxproducto.removeAllItems();
            jComboBoxproducto.addItem("Seleccione producto:");

            while (rs.next()) {
                String nombre = rs.getString("nombre").trim();
                int id = rs.getInt("id");
                jComboBoxproducto.addItem(nombre);
                productoMap.put(nombre, id);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar productos: " + e.getMessage());
        }
    }

   private boolean esNumerico(String valor) {
    try {
        Integer.parseInt(valor);
        return true;
    } catch (NumberFormatException e) {
        return false;
    }
}

    protected void DatosDelProducto() {
    String nombreProducto = jComboBoxproducto.getSelectedItem().toString().trim();
        
        if (productoMap.containsKey(nombreProducto)) {
            int productId = productoMap.get(nombreProducto);
            
            try (Connection conn = new CreateConection().getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                    "SELECT id, nombre, precio, stock, iva FROM producto WHERE id = ?")) {
                
                ps.setInt(1, productId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        idproducto = rs.getInt("id");
                        nombre = rs.getString("nombre");
                        preciounitario = rs.getDouble("precio");
                        cantidadproducto = rs.getInt("stock");
                        porcentajeIva = rs.getInt("iva");
                    }
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al obtener datos del producto: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Producto no encontrado en el mapa", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarTotales() {
      
    double subtotal = 0;
        double ivaTotal = 0;

        for (Detalle_Venta detalle : listaProductos) {
            subtotal += detalle.getSubtotal();
            ivaTotal += detalle.getIva();
        }

        double total = subtotal + ivaTotal;

        // Formatear con 2 decimales
        txtSubtotal.setText(String.format("Q.%.2f", subtotal));
        txtIva.setText(String.format("Q.%.2f", ivaTotal));
        txtTotalpagar.setText(String.format("Q.%.2f", total));
    }
    private void asignarIdCliente() {
    if (jComboBoxcliente2.getSelectedIndex() > 0) {
        String nombreCompleto = jComboBoxcliente2.getSelectedItem().toString();
        try (Connection conn = new CreateConection().getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT id FROM cliente WHERE CONCAT(nombre, ' ', apellido) = ?")) {
            ps.setString(1, nombreCompleto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    txtIdcliente.setText(rs.getString("id"));
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al obtener ID del cliente: " + ex.getMessage());
        }
    }
}

private void asignarIdUsuario() {
    if (jComboBoxUsuario.getSelectedIndex() > 0) {
        String nombreCompleto = jComboBoxUsuario.getSelectedItem().toString();
        try (Connection conn = new CreateConection().getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT id FROM empleado WHERE CONCAT(nombre, ' ', apellido) = ?")) {
            ps.setString(1, nombreCompleto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    txtIdusuario.setText(rs.getString("id"));
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al obtener ID del empleado: " + ex.getMessage());
        }
    }
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAñadirproducto;
    private javax.swing.JButton btnBuscarcliente;
    private javax.swing.JButton btnBuscarusuario;
    private javax.swing.JButton btnCalcularcambio;
    private javax.swing.JButton btnRegistarventa;
    private javax.swing.JComboBox<String> jComboBoxUsuario;
    private javax.swing.JComboBox<String> jComboBoxcliente2;
    private javax.swing.JComboBox<String> jComboBoxproducto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    public static javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable_productos;
    private javax.swing.JLabel lblWalpaper;
    private javax.swing.JTextField txtCambio;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtClientebuscar2;
    private javax.swing.JTextField txtDescuento;
    private javax.swing.JTextField txtEfectivo;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtIdcliente;
    private javax.swing.JTextField txtIdusuario;
    private javax.swing.JTextField txtIva;
    private javax.swing.JTextField txtSubtotal;
    public static javax.swing.JTextField txtTotalpagar;
    private javax.swing.JTextField txtUsuariobuscar;
    // End of variables declaration//GEN-END:variables
}
