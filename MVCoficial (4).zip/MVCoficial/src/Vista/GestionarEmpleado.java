package Vista;

import Conexion.CreateConection;
import Modelo.Empleados;
import Controlador.EmpleadoController;
import java.awt.Dimension;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GestionarEmpleado extends javax.swing.JInternalFrame {
private String currentFilter = "";
    private String originalFilter = "";
     private java.awt.event.ActionListener categoriaListener;
    private final EmpleadoController controlador = new EmpleadoController();
    private boolean ignoreCategoriaChange = false;

    public GestionarEmpleado() {
        initComponents();
        jTextField1.setEditable(false);
        this.setSize(new Dimension(900, 526));
        this.setTitle("Gestionar Empleados");
        configurarSeleccionTabla();
        CargarTablaGestionar("");
        ImageIcon imagenOriginal = new ImageIcon("src/img/fondo3.jpg");
        Image imagenEscalada = imagenOriginal.getImage().getScaledInstance(900, 526, Image.SCALE_SMOOTH);
        lblWalpaper2.setIcon(new ImageIcon(imagenEscalada));
        this.repaint();
        jComboBoxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{
            "Seleccione Estado",
            "activo",
            "inactivo"
        }));

      categoriaListener = evt -> {
    if (!ignoreCategoriaChange) {
        String estado = jComboBoxEstado.getSelectedItem().toString().trim();
        currentFilter = estado;
        CargarTablaGestionar(estado);
    }
};
        jComboBoxEstado.addActionListener(categoriaListener);
    }
private boolean validarCampos() {
    // Validar que ningún campo esté vacío
    if (txtNombre.getText().trim().isEmpty()
        || txtApellido.getText().trim().isEmpty()
        || txtPuesto.getText().trim().isEmpty()
        || txtTelefono.getText().trim().isEmpty()
        || txtDireccion.getText().trim().isEmpty()
        || txtFecha.getText().trim().isEmpty()
        || txtSalario.getText().trim().isEmpty()
        || txtEmail.getText().trim().isEmpty()) {

        JOptionPane.showMessageDialog(
            this, 
            "Complete todos los campos", 
            "Error", 
            JOptionPane.WARNING_MESSAGE
        );
        return false;
    }
    return true;
}
    private void configurarSeleccionTabla() {
         jTable_gestionar.getSelectionModel().addListSelectionListener(e -> {
        if (!e.getValueIsAdjusting()) {
            int fila = jTable_gestionar.getSelectedRow();
            if (fila >= 0) {
                try {
                    ignoreCategoriaChange = true;
                    jComboBoxEstado.removeActionListener(categoriaListener);

                    originalFilter = currentFilter; 

                        int id = (int) jTable_gestionar.getValueAt(fila, 0);
                        Empleados empleado = controlador.obtenerEmpleadoPorId(id);

                        if (empleado != null) {
                            jTextField1.setText(String.valueOf(empleado.getId())); 
                            txtNombre.setText(empleado.getNombre());
                            txtApellido.setText(empleado.getApellido());
                            txtPuesto.setText(empleado.getPuesto());
                            txtTelefono.setText(empleado.getTelefono());
                            txtDireccion.setText(empleado.getDireccion());
                            jComboBoxEstado.setSelectedItem(empleado.isEstado() ? "activo" : "inactivo");
                            txtFecha.setText(empleado.getFecha());
                            txtSalario.setText(String.valueOf(empleado.getSalario()));
                            txtEmail.setText(empleado.getEmail());
                        }

                     } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Error al cargar empleado: " + ex.getMessage());
                } finally {
                    ignoreCategoriaChange = false;
                    jComboBoxEstado.addActionListener(categoriaListener);}
                }
            }
        });
    }

    private void limpiarCampos() {
         jTextField1.setText("");
        txtNombre.setText("");
        txtApellido.setText("");
        txtPuesto.setText("");
        txtTelefono.setText("");
        txtDireccion.setText("");
        jComboBoxEstado.setSelectedIndex(0);
        txtFecha.setText("");
        txtSalario.setText("");
        txtEmail.setText("");
    }

    @SuppressWarnings("unchecked")
    private void CargarTablaGestionar(String estadoFiltro) {
        DefaultTableModel model = (DefaultTableModel) jTable_gestionar.getModel();
        model.setRowCount(0);

        String sql;
        PreparedStatement ps;

        try (Connection conn = new CreateConection().getConnection()) {
            if (estadoFiltro.equals("Seleccione Estado") || estadoFiltro.isEmpty()) {
                sql = "SELECT id, nombre, apellido, puesto, telefono, direccion, estado, fecha, salario, email FROM empleado";
                ps = conn.prepareStatement(sql);
            } else {
                sql = "SELECT id, nombre, apellido, puesto, telefono, direccion, estado, fecha, salario, email FROM empleado WHERE estado = ?";
                ps = conn.prepareStatement(sql);
                ps.setBoolean(1, estadoFiltro.equals("activo"));
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("puesto"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getBoolean("estado") ? "activo" : "inactivo",
                    rs.getString("fecha"),
                    rs.getDouble("salario"),
                    rs.getString("email")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar empleados: " + e.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_gestionar = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jComboBoxEstado = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        txtSalario = new javax.swing.JTextField();
        txtPuesto = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        lblWalpaper2 = new javax.swing.JLabel();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Gestionar Emleados");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 0, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable_gestionar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Apellido", "Puesto", "Telefono", "Direccion", "Estado", "Fecha ingreso", "Salario", "Email"
            }
        ));
        jScrollPane1.setViewportView(jTable_gestionar);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 820, 270));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 840, 300));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Nombre:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        txtNombre.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel3.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 120, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Estado:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        txtApellido.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtApellido.setPreferredSize(new java.awt.Dimension(70, 21));
        jPanel3.add(txtApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 40, 130, -1));

        txtEmail.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtEmail.setPreferredSize(new java.awt.Dimension(70, 21));
        jPanel3.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 90, 130, -1));

        txtDireccion.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtDireccion.setPreferredSize(new java.awt.Dimension(70, 21));
        txtDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionActionPerformed(evt);
            }
        });
        jPanel3.add(txtDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 40, 120, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setText("Apellido:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 20, -1, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setText("Direccion:");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 20, -1, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel8.setText("Email:");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 70, -1, -1));

        jComboBoxEstado.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jComboBoxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione Estado", "acitvo ", "inactivo" }));
        jComboBoxEstado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxEstadoActionPerformed(evt);
            }
        });
        jPanel3.add(jComboBoxEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 120, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btnActualizar.setBackground(new java.awt.Color(153, 255, 153));
        btnActualizar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(255, 153, 153));
        btnEliminar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnActualizar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnEliminar)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnActualizar)
                    .addComponent(btnEliminar))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 70, 190, 50));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel7.setText("Fecha Ingreso:");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, -1, -1));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel9.setText("Salrio:");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 70, -1, -1));

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel10.setText("Puesto:");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 20, -1, -1));

        txtFecha.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtFecha.setPreferredSize(new java.awt.Dimension(70, 21));
        txtFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechaActionPerformed(evt);
            }
        });
        jPanel3.add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, 120, -1));

        txtSalario.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtSalario.setPreferredSize(new java.awt.Dimension(70, 21));
        txtSalario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalarioActionPerformed(evt);
            }
        });
        jPanel3.add(txtSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 90, 120, -1));

        txtPuesto.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtPuesto.setPreferredSize(new java.awt.Dimension(70, 21));
        txtPuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPuestoActionPerformed(evt);
            }
        });
        jPanel3.add(txtPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 40, 120, -1));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel11.setText("Telefono:");
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, -1, -1));

        txtTelefono.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtTelefono.setPreferredSize(new java.awt.Dimension(70, 21));
        jPanel3.add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 40, 140, -1));

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel3.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 40, 50, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Id:");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 20, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, 790, 130));
        getContentPane().add(lblWalpaper2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 490));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed

         try {
        // Verificar si el ID está vacío
        if (jTextField1.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Seleccione un empleado", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = Integer.parseInt(jTextField1.getText().trim());
        boolean estado = jComboBoxEstado.getSelectedItem().toString().equalsIgnoreCase("activo");

        if (!validarCampos()) return;

        // Actualizar empleado usando el controlador
        controlador.actualizarEmpleado(
            id,
            txtNombre.getText(),
            txtApellido.getText(),
            txtPuesto.getText(),
            txtTelefono.getText(),
            txtDireccion.getText(),
            estado,
            txtFecha.getText(),
            Double.parseDouble(txtSalario.getText()),
            txtEmail.getText()
        );

        JOptionPane.showMessageDialog(this, "¡Empleado actualizado!");
        CargarTablaGestionar(originalFilter);
        ignoreCategoriaChange = true;
        jComboBoxEstado.setSelectedItem(originalFilter);
        ignoreCategoriaChange = false;
        limpiarCampos();

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Formato de salario inválido", "Error", JOptionPane.ERROR_MESSAGE);
    }

    

    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed

        int filaSeleccionada = jTable_gestionar.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una Empleado");
            return;
        }

        int id = (int) jTable_gestionar.getValueAt(filaSeleccionada, 0);
        try {
            // Usar el controlador
            if (controlador.eliminarEmpleado(id)) {
                JOptionPane.showMessageDialog(this, "Empleado eliminada");
                CargarTablaGestionar(jComboBoxEstado.getSelectedItem().toString());
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }


    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDireccionActionPerformed

    private void jComboBoxEstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxEstadoActionPerformed

      

    }//GEN-LAST:event_jComboBoxEstadoActionPerformed

    private void txtFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFechaActionPerformed

    private void txtSalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSalarioActionPerformed

    private void txtPuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPuestoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPuestoActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBoxEstado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    public static javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable_gestionar;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lblWalpaper2;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPuesto;
    private javax.swing.JTextField txtSalario;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables

}
