package Vista;

import Conexion.CreateConection;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import javax.swing.JOptionPane;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.DocumentException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.Desktop;
import java.io.File;

public class Reportes1 {

    public void ReportesUsuarios() {
        File tempFile = null;
        try {
            // Crear archivo temporal en lugar de usar ruta fija
            tempFile = File.createTempFile("Reportes_Clientes_", ".pdf");
            tempFile.deleteOnExit(); // Se eliminará al salir de la aplicación
            
            Document documento = new Document();
            try {
                PdfWriter.getInstance(documento, new FileOutputStream(tempFile));

                Paragraph parrafo = new Paragraph();
                parrafo.setAlignment(Paragraph.ALIGN_CENTER);
                parrafo.setFont(FontFactory.getFont("Tahoma", 18, Font.BOLD, BaseColor.DARK_GRAY));
                parrafo.add("Reporte creado por \nSistema de Gestión\n\n");
                parrafo.add("Reporte de Usuarios \n\n");

                documento.open();
                documento.add(Chunk.NEWLINE);
                documento.add(parrafo);
                
                PdfPTable tabla = new PdfPTable(8);
                tabla.setWidthPercentage(100);
                
                // Encabezados de tabla
                tabla.addCell("ID Usuario");
                tabla.addCell("Nombre");
                tabla.addCell("Apellido");
                tabla.addCell("Email");
                tabla.addCell("Teléfono");
                tabla.addCell("Dirección");
                tabla.addCell("Password");
                tabla.addCell("Usuario");

                try (Connection conn = new CreateConection().getConnection()) {
                    String sql = "SELECT idusuario, nombre, apellido, email, telefono, direccion, password, usuario FROM usuarios";
                    try (PreparedStatement ps = conn.prepareStatement(sql);
                         ResultSet rs = ps.executeQuery()) {
                        
                        while (rs.next()) {
                            tabla.addCell(rs.getString("idusuario"));
                            tabla.addCell(rs.getString("nombre"));
                            tabla.addCell(rs.getString("apellido"));
                            tabla.addCell(rs.getString("email"));
                            tabla.addCell(rs.getString("telefono"));
                            tabla.addCell(rs.getString("direccion"));
                            tabla.addCell(rs.getString("password"));
                            tabla.addCell(rs.getString("usuario"));
                        }
                    }
                    documento.add(tabla);
                
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Error en base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    System.err.println("Error en BD: " + e);
                }
                
                documento.close();
                
                // Abrir el PDF temporal automáticamente
                abrirPDF(tempFile.getAbsolutePath());
                
                JOptionPane.showMessageDialog(null, "Reporte generado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                
            } catch (DocumentException | FileNotFoundException e) {
                JOptionPane.showMessageDialog(null, "Error al generar PDF: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                System.err.println("Error en documento: " + e);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al crear archivo temporal: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Método para abrir el PDF con la aplicación predeterminada
    private void abrirPDF(String filePath) {
        try {
            File archivoPDF = new File(filePath);
            if (archivoPDF.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(archivoPDF);
                } else {
                    JOptionPane.showMessageDialog(null, 
                        "No se puede abrir el archivo automáticamente en este entorno", 
                        "Advertencia", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, 
                    "El archivo PDF no se encontró en: " + filePath, 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, 
                "Error al abrir el PDF: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, 
                "Error inesperado al abrir el PDF: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}