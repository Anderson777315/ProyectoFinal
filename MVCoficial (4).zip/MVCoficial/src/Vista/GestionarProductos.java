package Vista;

import Conexion.CreateConection;
import Modelo.Producto;
import Controlador.ProductoController;
import java.awt.Dimension;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GestionarProductos extends javax.swing.JInternalFrame {

    private java.awt.event.ActionListener categoriaListener;
    private final ProductoController controlador = new ProductoController();
 private boolean ignoreCategoriaChange = false;

    
    public GestionarProductos() {
        initComponents();
        this.setSize(new Dimension(900, 500));
        this.setTitle("Gestionar Productos");
        //this.CargarTablaGestionar();
        configurarSeleccionTabla();
        CargarTablaGestionar("");
        //Insertar imagen en nuestro lblWalpaper
        ImageIcon imagenOriginal = new ImageIcon("src/img/fondo3.jpg"); // Ruta corregida
        Image imagenEscalada = imagenOriginal.getImage()
                .getScaledInstance(900, 500, Image.SCALE_SMOOTH); // Parámetros correctos
        lblWalpaper2.setIcon(new ImageIcon(imagenEscalada));
        this.repaint();
        jComboBox_categoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{
            "Seleccione Categoria",
            "Bebidas",
            "Entradas",
            "Platos",
            "Postres",
            "Especialidades",
            "Menú infantil",
            "Menú vegetariano",
            "Menú del día",
            "Combos", // Sin espacio al final
            "Salsas",
            "Bocadillos", // Mayúscula consistente
            "Cocteles",
            "Bebidas alcohólicas",
            "Desayunos",
            "Café",
            "Tés" // Sin espacio al final
        }));

   categoriaListener = new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            if (!ignoreCategoriaChange) { // Solo se ejecuta si el cambio NO es programático
                String categoria = jComboBox_categoria.getSelectedItem().toString().trim();
                CargarTablaGestionar(categoria);
            }
        }
    };

    // 3. Asigna el listener al comboBox
    jComboBox_categoria.addActionListener(categoriaListener);
}
    private double precioBase;

    private void configurarSeleccionTabla() {
 jTable_gestionar.getSelectionModel().addListSelectionListener(e -> {
        if (!e.getValueIsAdjusting()) {
            int fila = jTable_gestionar.getSelectedRow();
            if (fila >= 0) {
                try {
                    ignoreCategoriaChange = true; // Bloquear recarga de tabla
                    jComboBox_categoria.removeActionListener(categoriaListener);

                    int id = (int) jTable_gestionar.getValueAt(fila, 0);
                    Producto producto = controlador.obtenerProductoPorId(id);

                    if (producto != null) {
                        // Actualizar campos SIN disparar eventos
                        jComboBox_categoria.setSelectedItem(producto.getCategoria());
                        txtNombre.setText(producto.getNombre());
                        precioBase = producto.getPrecio();

                        // Calcular y mostrar precio con IVA
                        double precioConIva = precioBase * (1 + producto.getPorcentajeIva() / 100.0);
                        txtPrecio.setText(String.format("%.2f", precioConIva));

                        // Otros campos
                        txtDisponible.setText(producto.isDisponible() ? "Sí" : "No");
                        txtStock.setText(String.valueOf(producto.getStock()));

                        // Seleccionar IVA correspondiente
                        switch (producto.getPorcentajeIva()) {
                            case 12 -> jComboBox_iva.setSelectedItem("12%");
                            case 14 -> jComboBox_iva.setSelectedItem("14%");
                            default -> jComboBox_iva.setSelectedItem("No agregar Iva");
                        }
                    }

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Error al cargar producto: " + ex.getMessage());
                } finally {
                    // Restaurar configuración
                    ignoreCategoriaChange = false;
                    jComboBox_categoria.addActionListener(categoriaListener);
                }
            }
        }
    });
}

    private void limpiarCampos() {

        txtNombre.setText("");
        jComboBox_categoria.setSelectedIndex(0); // Índice 0: "Seleccione Categoria"
        txtPrecio.setText("");
        txtDisponible.setText("");
        txtStock.setText("");

    }

    @SuppressWarnings("unchecked")
    protected void CargarTablaGestionar(String categoriaFiltro) {
        DefaultTableModel model = (DefaultTableModel) jTable_gestionar.getModel();
        model.setRowCount(0); // Limpiar la tabla

        String sql;
        PreparedStatement ps;

        try (Connection conn = new CreateConection().getConnection()) {
            if (categoriaFiltro.equals("Seleccione Categoria") || categoriaFiltro.isEmpty()) {
                // Cargar todos los productos si no hay filtro
                sql = "SELECT id, nombre, categoria, precio, disponible, stock, iva FROM producto";
                ps = conn.prepareStatement(sql);
            } else {
                // Filtrar por categoría seleccionada
                sql = "SELECT id, nombre, categoria, precio, disponible, stock, iva FROM producto WHERE categoria = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, categoriaFiltro);
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                double precioBase = rs.getDouble("precio");
                int iva = rs.getInt("iva");
                double precioConIva = precioBase * (1 + iva / 100.0);

                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("categoria"),
                    String.format("%.2f", precioConIva),
                    rs.getBoolean("disponible") ? "Sí" : "No",
                    rs.getInt("stock"),
                    iva + "%"
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar productos: " + e.getMessage());
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_gestionar = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JTextField();
        txtDisponible = new javax.swing.JTextField();
        txtStock = new javax.swing.JTextField();
        jComboBox_iva = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jComboBox_categoria = new javax.swing.JComboBox<>();
        lblWalpaper2 = new javax.swing.JLabel();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Gestionar Productos");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 0, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable_gestionar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Categoria", "Precio", "Disponible", "Stock", "Iva"
            }
        ));
        jScrollPane1.setViewportView(jTable_gestionar);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 510, 300));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 530, 320));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btnActualizar.setBackground(new java.awt.Color(153, 255, 153));
        btnActualizar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(255, 153, 153));
        btnEliminar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(btnActualizar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(btnEliminar)
                .addGap(20, 20, 20))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnActualizar)
                    .addComponent(btnEliminar))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 280, 230, 60));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Nombre:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        txtNombre.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel3.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 40, 120, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Categoria:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, -1));

        txtPrecio.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtPrecio.setPreferredSize(new java.awt.Dimension(70, 21));
        jPanel3.add(txtPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, -1, -1));

        txtDisponible.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtDisponible.setPreferredSize(new java.awt.Dimension(70, 21));
        jPanel3.add(txtDisponible, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 130, -1, -1));

        txtStock.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtStock.setPreferredSize(new java.awt.Dimension(70, 21));
        txtStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtStockActionPerformed(evt);
            }
        });
        jPanel3.add(txtStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, -1, -1));

        jComboBox_iva.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jComboBox_iva.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione Iva:", "No agregar Iva", "12%", "14%" }));
        jComboBox_iva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_ivaActionPerformed(evt);
            }
        });
        jPanel3.add(jComboBox_iva, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 190, 120, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setText("Precio:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setText("Stock:");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, -1, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel7.setText("Iva:");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, -1, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel8.setText("Disponible:");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));

        jComboBox_categoria.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jComboBox_categoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione Categoria", "Bebidas", "Entradas", "Platos", "Postres", "Especialidades", "Menú infantil", "Menú vegetariano", "Menú del día", "Combos ", "Salsas ", "bocadillos", "Cocteles ", "bebidas alcohólicas", "Desayunos", "Café ", "tés  " }));
        jComboBox_categoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_categoriaActionPerformed(evt);
            }
        });
        jPanel3.add(jComboBox_categoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 70, 150, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 40, 280, 230));

        lblWalpaper2.setText("jLabel9");
        getContentPane().add(lblWalpaper2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed

        try {
            int filaSeleccionada = jTable_gestionar.getSelectedRow();

            if (filaSeleccionada == -1) {
                JOptionPane.showMessageDialog(this, "Seleccione un producto", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int id = (int) jTable_gestionar.getValueAt(filaSeleccionada, 0);
            String nombre = txtNombre.getText().trim();
            int stock = Integer.parseInt(txtStock.getText().trim());

            // Convertir "Sí"/"No" a boolean
            String disponibleText = txtDisponible.getText().trim();
            boolean disponible = disponibleText.equalsIgnoreCase("Sí") || disponibleText.equalsIgnoreCase("Si");

            String ivaSeleccionado = jComboBox_iva.getSelectedItem().toString().trim();
            int porcentajeIva = obtenerPorcentajeIVA(ivaSeleccionado);
            String categoria = jComboBox_categoria.getSelectedItem().toString().trim();

            if (categoria.equals("Seleccione Categoria")) {
                JOptionPane.showMessageDialog(this, "Seleccione una categoría válida", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Usa precioBase (sin IVA) para la actualización
            controlador.actualizarProducto(
                    id,
                    nombre,
                    precioBase, // Precio SIN IVA
                    stock,
                    disponible,
                    porcentajeIva,
                    categoria
            );

            JOptionPane.showMessageDialog(this, "¡Producto actualizado!");
            CargarTablaGestionar(jComboBox_categoria.getSelectedItem().toString());
            limpiarCampos();

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error en formato numérico: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

// Método para validar campos
    private boolean validarCampos() {
        if (txtNombre.getText().trim().isEmpty()
                || txtPrecio.getText().trim().isEmpty()
                || txtStock.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(this, "Complete todos los campos", "Error", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

// Método para obtener el porcentaje de IVA
    private int obtenerPorcentajeIVA(String ivaSeleccionado) {
        switch (ivaSeleccionado) {
            case "No agregar Iva":
                return 0;
            case "12%":
                return 12;
            case "14%":
                return 14;
            default:
                return 0;
        }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed

        int filaSeleccionada = jTable_gestionar.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una Producto");
            return;
        }

        int id = (int) jTable_gestionar.getValueAt(filaSeleccionada, 0);
        try {
            // Usar el controlador
            if (controlador.eliminarProducto(id)) {
                JOptionPane.showMessageDialog(this, "Producto eliminada");
                CargarTablaGestionar(jComboBox_categoria.getSelectedItem().toString());
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }


    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtStockActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtStockActionPerformed

    private void jComboBox_ivaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_ivaActionPerformed
        String ivaSeleccionado = jComboBox_iva.getSelectedItem().toString().trim();
        int porcentajeIva = obtenerPorcentajeIVA(ivaSeleccionado);

        // Calcular nuevo precio con IVA
        double nuevoPrecio = precioBase * (1 + porcentajeIva / 100.0);
        txtPrecio.setText(String.format("%.2f", nuevoPrecio));


    }//GEN-LAST:event_jComboBox_ivaActionPerformed

    private void jComboBox_categoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_categoriaActionPerformed

      

    }//GEN-LAST:event_jComboBox_categoriaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox_categoria;
    private javax.swing.JComboBox<String> jComboBox_iva;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    public static javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable_gestionar;
    private javax.swing.JLabel lblWalpaper2;
    private javax.swing.JTextField txtDisponible;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtStock;
    // End of variables declaration//GEN-END:variables

}
