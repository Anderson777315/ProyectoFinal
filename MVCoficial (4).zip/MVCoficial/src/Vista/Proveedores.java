/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package Vista;

import Controlador.ProveedorController;
import Modelo.Proveedor;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
///////////
import javax.swing.JTable;
import java.awt.Dimension;

public class Proveedores extends javax.swing.JInternalFrame {

    private final ProveedorController controlador = new ProveedorController();

    public Proveedores() {
        initComponents();
        this.setSize(new Dimension(375, 435));
        this.setTitle("Proveedor");
    }

    private void limpiarCampos() {
        txtnombre.setText("");
        txtnit.setText("");
        txtcontacto.setText("");
        txtdireccion.setText("");
        txttelefonoemp.setText("");
        txttelefonocon.setText("");

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txttelefonoemp = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txttelefonocon = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        insertar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtnombre = new javax.swing.JTextField();
        txtnit = new javax.swing.JTextField();
        txtcontacto = new javax.swing.JTextField();
        txtdireccion = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        lblwallpaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txttelefonoemp.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txttelefonoemp, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 210, 140, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nombre:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        txttelefonocon.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txttelefonocon, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, 140, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("NIT:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, -1, -1));

        insertar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        insertar.setText("Insertar");
        insertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertarActionPerformed(evt);
            }
        });
        getContentPane().add(insertar, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, -1, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Contacto:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, -1, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Direccion:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Telefono_empresa:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, -1, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Telefono_contacto:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, -1));

        txtnombre.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 190, -1));

        txtnit.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtnit, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 190, -1));

        txtcontacto.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtcontacto, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 190, -1));

        txtdireccion.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        getContentPane().add(txtdireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, 190, -1));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nuevo Proveedor");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, -1, -1));

        lblwallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/crea un fondo realista para un p.png"))); // NOI18N
        getContentPane().add(lblwallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 400));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void insertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertarActionPerformed
      
        if (txtnombre.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (txtnit.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nit es obligatorio", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (txtcontacto.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El contacto es obligatorio", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (txtdireccion.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El direccion es obligatorio", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (txttelefonoemp.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "La telefono de la empresa es obligatoria", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
         if (txttelefonocon.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "La telefono de contacto es obligatoria", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {

        controlador.agregarProveedor(txtnombre.getText(), txtnit.getText(), txtcontacto.getText(), txtdireccion.getText(), txttelefonoemp.getText(), txttelefonocon.getText());
         JOptionPane.showMessageDialog(this, "Cliente agregado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            limpiarCampos(); // Limpiar los campos después de agregar
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        limpiarCampos();
    }//GEN-LAST:event_insertarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton insertar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel lblwallpaper;
    private javax.swing.JTextField txtcontacto;
    private javax.swing.JTextField txtdireccion;
    private javax.swing.JTextField txtnit;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txttelefonocon;
    private javax.swing.JTextField txttelefonoemp;
    // End of variables declaration//GEN-END:variables
}
