/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CreateConexion1 {
     public static Connection getCreateConexion1() {
        Connection conn = null;

        // Parámetros de la base de datos remota (Neon)
        String url = "jdbc:postgresql://ep-round-smoke-a4csfc4i-pooler.us-east-1.aws.neon.tech:5432/neondb?sslmode=require";
        String user = "neondb_owner";
        String password = "npg_QW6Yno2hRbcP";

        try {
            conn = DriverManager.getConnection(url, user, password);
            System.out.println(" Conexión exitosa a la base de datos.");
        } catch (SQLException e) {
            System.err.println(" Error de conexión: " + e.getMessage());
        }

        return conn;
    }
}
