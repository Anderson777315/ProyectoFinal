/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
  
import Conexion.CreateConection;
import Modelo.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
      private final CreateConection connFactory = new CreateConection();

    public List<Cliente> obtenerTodos() {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM CLIENTE";

        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Cliente cli = new Cliente(
                        rs.getInt("ID"),
                        rs.getString("NOMBRE"),
                    rs.getString("APELLIDO"),
                    rs.getString("GMAIL"),
                    rs.getString("TELEFONO"),
                    rs.getString("DIRECCION")
             
               );
                lista.add(cli);
            }
          /*  ps.close();
            conn.close();*/
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean guardar(Cliente cli) {
String sql = "INSERT INTO CLIENTE (nombre, apellido, gmail, telefono, direccion) VALUES (?, ?, ?, ?, ? )";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cli.getNombre());
        ps.setString(2, cli.getApellido());
          ps.setString(3, cli.getEmail());
        ps.setString(4, cli.getTelefono());
        ps.setString(5, cli.getDireccion());

            ps.executeUpdate();
            ps.close();
            conn.close();
            
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean actualizar(Cliente cli) {
        String sql = "UPDATE cliente SET nombre=?, apellido=?, gmail=?, telefono=? WHERE ID=?";

        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) { 
        ps.setString(1, cli.getNombre());
        ps.setString(2, cli.getApellido());
        ps.setString(4, cli.getEmail());
        ps.setString(5, cli.getTelefono());
     
       
       
       
        ps.setInt(6, cli.getId());

            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM CLIENTE WHERE ID=?";

        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
        
    }

}
