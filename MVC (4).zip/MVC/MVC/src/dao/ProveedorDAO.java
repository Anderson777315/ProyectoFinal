/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Conexion.CreateConection;
import Modelo.Proveedor;

public class ProveedorDAO {
     private final CreateConection connFactory = new CreateConection();

    public List<Proveedor> obtenerTodos() {
        List<Proveedor> lista = new ArrayList<>();
        String sql = "SELECT * FROM Proveedor";

        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Proveedor emp = new Proveedor(
                    rs.getString("NOMBRE"),
                    rs.getString("NIT"),
                    rs.getString("CONTACTO"),
                    rs.getString("DiRECCION"),
                    rs.getString("TELEFONOEMP"), 
                    rs.getString("TELEFONOCON")
                );
                
            }
          /*  ps.close();
            conn.close();*/
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public boolean guardar(Proveedor emp) {
String sql = "INSERT INTO PROVEEDOR (nombre, nit, contacto, direccion, telefono_empresa, telefono_contacto) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, emp.getNombre());
        ps.setString(2, emp.getNit());
        ps.setString(3, emp.getContacto());
        ps.setString(4, emp.getDireccion());
        ps.setString(5, emp.getTelefonoEmp());
        ps.setString(6, emp.getTelefonoCon());
            ps.executeUpdate();
            ps.close();
            conn.close();
            
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}
